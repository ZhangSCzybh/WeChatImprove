// Behavioral layout/privacy checks against the production presentation source.
static BOOL Visible(UIView *view) { for(UIView *v=view;v;v=v.superview)if(v.hidden)return NO;return YES; }
static UILabel *VisibleLabel(UIView *view,NSString *text) {
    if(!Visible(view))return nil;
    if([view isKindOfClass:UILabel.class] && [((UILabel *)view).text isEqual:text])return (UILabel *)view;
    for(UIView *child in view.subviews){UILabel *found=VisibleLabel(child,text);if(found)return found;}return nil;
}
static void NativeFoldedLayoutTests(void) {
    policy=Policy(NO);
    NewMainFrameCell *cell=[[NewMainFrameCell alloc] initWithFrame:CGRectMake(0,0,390,76)];
    UIView *content=[[UIView alloc] initWithFrame:cell.bounds];[cell addSubview:content];
    UIView *card=[[UIView alloc] initWithFrame:CGRectMake(15,0,360,76)];card.backgroundColor=UIColor.systemBackgroundColor;[content addSubview:card];
    MainFrameItemView *item=[[MainFrameItemView alloc] initWithFrame:card.frame];cell->m_itemView=item;[content addSubview:item];
    item->m_frameHeadView=[[UIView alloc] initWithFrame:CGRectMake(12,14,48,48)];[item addSubview:item->m_frameHeadView];
    item->m_nameLabel=[[UILabel alloc] initWithFrame:CGRectMake(72,14,150,22)];item->m_nameLabel.text=@"折叠的聊天";
    item->m_messageLabel=[[UILabel alloc] initWithFrame:CGRectMake(184,42,100,18)];item->m_messageLabel.text=@"another group secret";
    item->m_timeLabel=[[UILabel alloc] initWithFrame:CGRectMake(300,14,48,16)];item->m_timeLabel.text=@"10:24";
    item->m_unreadCountView=[[UIView alloc] initWithFrame:CGRectMake(45,0,18,18)];
    [item->m_frameHeadView addSubview:item->m_unreadCountView];
    for(UILabel *label in @[item->m_nameLabel,item->m_messageLabel,item->m_timeLabel]){
        label.font=[UIFont preferredFontForTextStyle:UIFontTextStyleBody];label.textColor=UIColor.labelColor;[item addSubview:label];
    }
    item->m_messageLabel.font=[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    UIView *separator=[[UIView alloc] initWithFrame:CGRectMake(87,75.5,288,.5)];[content addSubview:separator];
    CGRect originalCell=cell.frame,originalCard=card.frame,originalIcon=item->m_frameHeadView.frame,originalTitle=item->m_nameLabel.frame;
    UIFont *originalFont=item->m_nameLabel.font;NSUInteger originalNativeChildren=item.subviews.count;
    CSCloseFriendUpdateSessionCover(cell,ScopedRow(4,YES,1));
    CSCloseFriendSessionCover *cover=objc_getAssociatedObject(cell,&CoverKey);
    UILabel *title=VisibleLabel(cell,@"折叠的聊天"),*summary=VisibleLabel(cell,@"visible-3: [图片]");
    Check(Visible(content) && Visible(card) && Visible(item) && Visible(item->m_frameHeadView) && Visible(separator),@"folded row retains native content, card, aggregate icon and separator");
    Check(CGRectEqualToRect(cell.frame,originalCell) && CGRectEqualToRect(card.frame,originalCard) && CGRectEqualToRect(item->m_frameHeadView.frame,originalIcon),@"folded row retains ordinary session height, margins and icon geometry");
    Check(title==item->m_nameLabel && Visible(title) && cover.titleLabel.hidden && title.font==originalFont && CGRectEqualToRect(title.frame,originalTitle),@"native title label remains visible with original text/font/frame and no duplicate overlay title");
    Check(title && [title.text isEqual:@"折叠的聊天"] && !title.adjustsFontSizeToFitWidth && title.font.pointSize>=17,@"title contains no count and never shrinks below native type size");
    Check(summary && summary.superview==cover && cover.backgroundColor.transparent && summary.frame.origin.x==72 && summary.frame.origin.y==42 && summary.frame.size.width==276,@"verified native child summary uses native two-line geometry and title left edge");
    Check(summary.textAlignment==NSTextAlignmentLeft && !summary.adjustsFontSizeToFitWidth && summary.font==item->m_messageLabel.font && summary.textColor==item->m_messageLabel.textColor,@"summary preserves native typography and left alignment without shrinking messages");
    Check(Visible(item->m_nameLabel) && !Visible(item->m_messageLabel) && !Visible(item->m_timeLabel) && !Visible(item->m_unreadCountView),@"native title is retained while global preview/time/nested badge remain concealed");
    Check([item->m_messageLabel.text isEqual:@"another group secret"] && [item->m_timeLabel.text isEqual:@"10:24"],@"presentation never rewrites global native message/time labels");
    NSUInteger children=item.subviews.count;
    item->m_messageLabel.hidden=NO;item->m_timeLabel.hidden=NO;item->m_unreadCountView.hidden=NO;
    item->m_messageLabel.frame=CGRectMake(80,43,230,19);item->m_messageLabel.textColor=UIColor.secondaryLabelColor;
    UIView *late=[[UIView alloc] initWithFrame:CGRectMake(300,40,20,20)];[item addSubview:late];
    __block NSUInteger originalLayouts=0;HookMainFrameItemLayout(item,^{originalLayouts++;});summary=VisibleLabel(cell,@"visible-3: [图片]");
    Check(originalLayouts==1,@"native item layout executes once before privacy repair");
    Check(summary && summary.superview==cover && summary.frame.origin.x==72 && summary.frame.origin.y==43 && summary.frame.size.height==19 && summary.frame.size.width==276 && summary.textColor==item->m_messageLabel.textColor,@"native relayout/theme updates summary metrics and color without another cover");
    Check(!Visible(late) && !Visible(item->m_timeLabel) && !Visible(item->m_unreadCountView) && Visible(item->m_frameHeadView),@"native relayout hides new business content while retaining aggregate icon");
    item.frame=CGRectMake(15,0,190,76);CSCloseFriendRefreshSessionCover(cell);
    Check(!title.adjustsFontSizeToFitWidth && title.font==originalFont && CGRectEqualToRect(title.frame,originalTitle),@"narrow card does not rewrite or shrink native title");
    item.frame=originalCard;CSCloseFriendRefreshSessionCover(cell);
    Check(CGRectEqualToRect(title.frame,originalTitle) && summary.frame.size.width==276,@"widening preserves original title and refreshes summary width");
    for(NSUInteger n=0;n<8;n++)CSCloseFriendRefreshSessionCover(cell);
    Check(item.subviews.count==children+1 && CGRectEqualToRect(cell.frame,originalCell),@"repeated rendering adds no rows/overlays or height changes");
    item->m_nameLabel.text=@"unexpected global title";CSCloseFriendRefreshSessionCover(cell);
    Check(!Visible(item->m_nameLabel) && Visible(cover.titleLabel) && [cover.titleLabel.text isEqual:@"折叠的聊天"] && !cover.titleLabel.adjustsFontSizeToFitWidth && cover.titleLabel.font==originalFont,@"unverified native title uses same-size fallback without rewriting the original");
    item->m_nameLabel.text=@"折叠的聊天";CSCloseFriendRefreshSessionCover(cell);
    Check(Visible(item->m_nameLabel) && cover.titleLabel.hidden,@"when native title becomes valid its owned hidden state is restored");
    CSCloseFriendUpdateSessionCover(cell,ScopedRow(0,NO,1));
    Check([cover.summaryLabel.text isEqual:@"折叠的聊天"] && !VisibleLabel(cell,@"visible-3: [图片]") && !Visible(item->m_messageLabel),@"unknown source becomes neutral with no stale digest or global preview");
    CSCloseFriendUpdateSessionCover(cell,nil);
    Check(Visible(item->m_nameLabel) && Visible(item->m_messageLabel) && Visible(item->m_timeLabel) && Visible(item->m_unreadCountView) && Visible(late) && item.subviews.count==originalNativeChildren+1,@"ordinary reuse restores native hidden states and removes only owned overlay");
    CSCloseFriendUpdateSessionCover(cell,ScopedRow(12,YES,1));
    title=VisibleLabel(cell,@"折叠的聊天");summary=VisibleLabel(cell,@"visible-11: [图片]");
    Check(title==item->m_nameLabel && summary && summary.frame.origin.x==title.frame.origin.x && !title.adjustsFontSizeToFitWidth,@"folded-ordinary-folded reuse shows current summary and original native title");
}
