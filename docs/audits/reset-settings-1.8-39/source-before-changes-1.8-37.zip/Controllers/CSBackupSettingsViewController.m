#import "CSBackupSettingsViewController.h"
#import "CSBackupManager.h"
#import "CSBackupBootstrap.h"
#import "CSBackupPreviewViewController.h"
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "CSNavigationTitleSettingsViewController.h"
#import "CSTabBarStyleSettingsViewController.h"
#import "CSTouchTrailViewController.h"
#import "CSContactSeparatorSettingsViewController.h"
#import "CSNativeSettingsHost.h"
@interface CSBackupRepairViewController : UITableViewController
@property(nonatomic) NSArray<NSString *> *contacts;
@end
@implementation CSBackupRepairViewController
- (void)viewDidLoad {[super viewDidLoad];self.title=@"修复当前配置";id contacts=[NSUserDefaults.standardUserDefaults objectForKey:@"com.wechat.tweak.navigation.contact.overrides"];self.contacts=[contacts isKindOfClass:NSDictionary.class]?[[contacts allKeys] sortedArrayUsingSelector:@selector(compare:)]:@[];}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {(void)tableView;(void)section;return 4+self.contacts.count;}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {(void)tableView;(void)section;return @"升级保护未能完成时，可在原有设置页面重新选择缺失图片或修正无效配置，然后返回备份页重试。插件功能在校验完成前保持等待；本页不会自动清除配置。其他设置仍使用原有授权检查。";}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {(void)tableView;UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];cell.textLabel.text=path.row<4?@[@"导航栏分隔图片",@"底栏普通及选中图标",@"触摸轨迹图片",@"其他插件设置"][path.row]:[@"联系人分隔图片 · " stringByAppendingString:self.contacts[path.row-4]];cell.textLabel.numberOfLines=0;cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;return cell;}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {[tableView deselectRowAtIndexPath:path animated:YES];UIViewController *controller=nil;switch(path.row){case 0:controller=[CSNavigationTitleSettingsViewController new];break;case 1:controller=[CSTabBarStyleSettingsViewController new];break;case 2:controller=[CSTouchTrailViewController new];break;case 3:controller=[[CSNativeSettingsControllerClass() alloc]init];break;default:controller=[[CSContactSeparatorSettingsViewController alloc]initWithContactId:self.contacts[path.row-4] contactName:nil contactAvatar:nil];break;}[self.navigationController pushViewController:controller animated:YES];}
@end

@interface CSBackupSettingsViewController () <UIDocumentPickerDelegate>
@property(nonatomic) NSArray *records;
@property(nonatomic) BOOL busy;
@end
@implementation CSBackupSettingsViewController
- (void)viewDidLoad {[super viewDidLoad];self.title=@"备份配置";self.tableView.backgroundColor=UIColor.systemGroupedBackgroundColor;self.records=@[];}
- (void)viewWillAppear:(BOOL)animated {[super viewWillAppear:animated];[self reload];}
- (void)setWorking:(BOOL)working {self.busy=working;self.tableView.userInteractionEnabled=!working;self.navigationItem.prompt=working?@"正在处理，请稍候…":nil;}
- (void)reload {[self setWorking:YES];[CSBackupManager.sharedManager list:^(NSArray *records,NSError *error){self.records=records?:@[];[self setWorking:NO];[self.tableView reloadData];if(error)[self message:@"备份检查" detail:error.localizedDescription];}];}
- (void)message:(NSString *)title detail:(NSString *)message {UIAlertController *alert=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];[self presentViewController:alert animated:YES completion:nil];}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {(void)tableView;return 3;}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {(void)tableView;return section==0?6:(section==1?self.records.count:1);}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {(void)tableView;return @[@"操作",@"本机备份",@"状态"][section];}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {(void)tableView;if(section==0)return @"自动备份在配置停止变化约 30 秒后尝试保存，持续编辑时约 5 分钟检查一次；相同内容不重复保存。默认保留 20 份自动备份与 5 份操作保护备份，手动、收藏和待恢复计划使用的备份会保留。";if(section==2)return @"备份包含插件配置、自定义图片和已存档账号分组。导出文件可能含成员、联系人标识和自定义文字，请自行选择保存位置。文件未加密；不包含微信消息、登录凭据或支付账本。旧版原件只读保留。";return nil;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    (void)tableView;UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];cell.textLabel.numberOfLines=0;cell.detailTextLabel.numberOfLines=0;
    if(path.section==0){cell.textLabel.text=@[@"创建备份",@"从文件导入",@"自动备份",@"取消待恢复计划",@"重试未完成的恢复",@"修复当前配置"][path.row];if(path.row==2){UISwitch *toggle=[UISwitch new];toggle.on=CSBackupManager.sharedManager.isAutoBackupEnabled;[toggle addTarget:self action:@selector(autoChanged:) forControlEvents:UIControlEventValueChanged];cell.accessoryView=toggle;}else cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;}
    else if(path.section==1){NSDictionary *record=self.records[path.row],*metadata=record[@"metadata"];cell.textLabel.text=metadata[@"name"]?:record[@"name"];NSString *kind=@{@"manual":@"手动",@"automatic":@"自动",@"protection":@"恢复前保护",@"upgrade":@"升级保护",@"imported":@"导入",@"legacy":@"旧版"}[record[@"kind"]]?:@"备份";
        NSDateFormatter *date=[NSDateFormatter new];date.dateStyle=NSDateFormatterShortStyle;date.timeStyle=NSDateFormatterShortStyle;
        cell.detailTextLabel.text=record[@"createdAt"]?[NSString stringWithFormat:@"%@%@ · %@\n%@ 项配置 · %@ 张图片 · %@",[metadata[@"favorite"] boolValue]?@"★ ":@"",kind,[date stringFromDate:record[@"createdAt"]],record[@"fieldCount"],record[@"assetCount"],[NSByteCountFormatter stringFromByteCount:[record[@"size"] longLongValue] countStyle:NSByteCountFormatterCountStyleFile]]:@"旧版原件 · 打开后转换并校验";cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }else{cell.textLabel.text=CSBackupManager.sharedManager.status;cell.selectionStyle=UITableViewCellSelectionStyleNone;}return cell;
}
- (void)autoChanged:(UISwitch *)sender {[CSBackupManager.sharedManager enableAutoBackup:sender.on];}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];if(self.busy)return;
    if(path.section==1){[self setWorking:YES];NSDictionary *record=self.records[path.row];[CSBackupManager.sharedManager load:record completion:^(NSDictionary *snapshot,NSError *error){[self setWorking:NO];if(error)[self message:@"无法读取备份" detail:error.localizedDescription];else [self showRecord:record snapshot:snapshot anchor:[tableView cellForRowAtIndexPath:path]];}];return;}
    if(path.section!=0)return;
    if(path.row==0)[self create];
    else if(path.row==1){UIDocumentPickerViewController *picker=[[UIDocumentPickerViewController alloc]initForOpeningContentTypes:@[UTTypeData] asCopy:YES];picker.delegate=self;picker.allowsMultipleSelection=NO;[self presentViewController:picker animated:YES completion:nil];}
    else if(path.row==3)[self confirmCancel];
    else if(path.row==5){[self setWorking:YES];[CSBackupManager.sharedManager checkRepairAccess:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"暂时不能修复" detail:error.localizedDescription];else [self.navigationController pushViewController:[[CSBackupRepairViewController alloc]initWithStyle:UITableViewStyleInsetGrouped] animated:YES];}];}
    else if(path.row==4){[self setWorking:YES];CSBackupRetryStartup(^(NSError *error){[self setWorking:NO];if(error)[self message:@"恢复仍待处理" detail:error.localizedDescription];else [self message:@"校验已完成" detail:@"请重新打开微信，以完整初始化所有插件功能。"];[self.tableView reloadData];});}
}
- (void)create {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"创建完整备份" message:@"保存当前插件配置、图片和账号分组。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field){field.placeholder=@"名称（可留空）";}];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action){NSString *name=[alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];if(!name.length){NSDateFormatter *date=[NSDateFormatter new];date.dateFormat=@"yyyy-MM-dd HH:mm";name=[@"手动备份 " stringByAppendingString:[date stringFromDate:NSDate.date]];}[self setWorking:YES];[CSBackupManager.sharedManager create:name completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"保存失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmCancel {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"取消待恢复计划" message:@"保留当前配置、原备份和保护备份。已开始但未完成的事务必须先回滚。" preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"返回" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"取消计划" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager cancelPending:^(__unused id result,NSError *error){[self setWorking:NO];if(error)[self message:@"无法取消" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)showRecord:(NSDictionary *)record snapshot:(NSDictionary *)snapshot anchor:(UIView *)anchor {
    NSString *message=[NSString stringWithFormat:@"来源版本 %@ · %lu 项配置 · %lu 张图片%@",snapshot[@"source"][@"pluginVersion"],(unsigned long)[snapshot[@"fields"] count],(unsigned long)[snapshot[@"assets"] count],[snapshot[@"warnings"] count]?[@"\n" stringByAppendingString:[snapshot[@"warnings"] componentsJoinedByString:@"\n"]]:@""];
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:record[@"metadata"][@"name"]?:snapshot[@"name"] message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:@"预览恢复" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self.navigationController pushViewController:[[CSBackupPreviewViewController alloc]initWithSnapshot:snapshot] animated:YES];}]];
    [alert addAction:[UIAlertAction actionWithTitle:@"导出到文件 / 分享" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager exportSnapshot:snapshot completion:^(NSURL *url,NSError *error){[self setWorking:NO];if(error){[self message:@"导出失败" detail:error.localizedDescription];return;}UIActivityViewController *share=[[UIActivityViewController alloc]initWithActivityItems:@[url] applicationActivities:nil];share.popoverPresentationController.sourceView=anchor?:self.view;share.popoverPresentationController.sourceRect=(anchor?:self.view).bounds;share.completionWithItemsHandler=^(__unused UIActivityType type,__unused BOOL complete,__unused NSArray *items,__unused NSError *shareError){[NSFileManager.defaultManager removeItemAtURL:url error:NULL];};[self presentViewController:share animated:YES completion:nil];}];}]];
    if(![record[@"legacy"] boolValue]){
        [alert addAction:[UIAlertAction actionWithTitle:@"重命名" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self renameRecord:record];}]];
        BOOL favorite=[record[@"metadata"][@"favorite"] boolValue];[alert addAction:[UIAlertAction actionWithTitle:favorite?@"取消收藏":@"收藏（保留不自动清理）" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){NSMutableDictionary *metadata=[record[@"metadata"] mutableCopy];metadata[@"favorite"]=favorite?@NO:@YES;[self setWorking:YES];[CSBackupManager.sharedManager updateMetadata:metadata record:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"修改失败" detail:error.localizedDescription];else [self reload];}];}]];
        [alert addAction:[UIAlertAction actionWithTitle:@"删除备份" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self deleteRecord:record];}]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];alert.popoverPresentationController.sourceView=anchor?:self.view;alert.popoverPresentationController.sourceRect=(anchor?:self.view).bounds;[self presentViewController:alert animated:YES completion:nil];
}
- (void)renameRecord:(NSDictionary *)record {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"重命名本机备份" message:@"仅修改本机显示名称，原始快照信息保留。" preferredStyle:UIAlertControllerStyleAlert];[alert addTextFieldWithConfigurationHandler:^(UITextField *field){field.text=record[@"metadata"][@"name"]?:record[@"name"];}];[alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){NSString *name=[alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];if(!name.length||name.length>128){[self message:@"名称无效" detail:@"请输入 1–128 个字符。"] ;return;}NSMutableDictionary *metadata=[record[@"metadata"] mutableCopy];metadata[@"name"]=name;[self setWorking:YES];[CSBackupManager.sharedManager updateMetadata:metadata record:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"修改失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)deleteRecord:(NSDictionary *)record {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"删除这份备份？" message:@"只删除所选备份，不改变当前配置。" preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager remove:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"删除失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {(void)controller;if(!urls.count)return;[self setWorking:YES];[CSBackupManager.sharedManager importURL:urls.firstObject completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"导入失败" detail:error.localizedDescription];else [self reload];}];}
@end
