#import "CSResetSettingsViewController.h"
#import "CSBackupManager.h"
#import "CSBackupPreviewViewController.h"
@implementation CSResetSettingsViewController
- (void)viewDidLoad {[super viewDidLoad];self.title=@"重置插件配置";self.tableView.backgroundColor=UIColor.systemGroupedBackgroundColor;}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {(void)tableView;(void)section;return 1;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {(void)tableView;(void)indexPath;UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];cell.textLabel.text=@"预览要重置的模块";cell.textLabel.textColor=UIColor.systemRedColor;cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;return cell;}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {(void)tableView;(void)section;return @"仅重置明确登记的插件配置。可选择模块和原所属账号；确认前生成保护备份，重新打开微信时应用。微信自身设置、登录状态、聊天记录、支付账本和统计保持不变。";}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {[tableView deselectRowAtIndexPath:indexPath animated:YES];tableView.userInteractionEnabled=NO;self.navigationItem.prompt=@"正在检查当前配置…";[CSBackupManager.sharedManager resetSnapshot:^(NSDictionary *snapshot,NSError *error){tableView.userInteractionEnabled=YES;self.navigationItem.prompt=nil;if(error){UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"无法准备重置" message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];[self presentViewController:alert animated:YES completion:nil];}else [self.navigationController pushViewController:[[CSBackupPreviewViewController alloc]initWithSnapshot:snapshot] animated:YES];}];}
@end
