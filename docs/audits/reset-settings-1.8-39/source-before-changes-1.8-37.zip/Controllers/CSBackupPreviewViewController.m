#import "CSBackupPreviewViewController.h"
#import "CSBackupManager.h"
#import "CSBackupRegistry.h"
@interface CSBackupPreviewViewController ()
@property(nonatomic) NSDictionary *snapshot;
@property(nonatomic) NSDictionary *preview;
@property(nonatomic) NSArray *modules;
@property(nonatomic) NSArray *accounts;
@property(nonatomic) NSMutableSet *selectedModules;
@property(nonatomic) NSMutableSet *selectedAccounts;
@property(nonatomic) NSString *message;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) BOOL busy;
@end
@implementation CSBackupPreviewViewController
- (instancetype)initWithSnapshot:(NSDictionary *)snapshot {if((self=[super initWithStyle:UITableViewStyleInsetGrouped]))_snapshot=snapshot;return self;}
- (void)viewDidLoad {
    [super viewDidLoad];self.title=@"预览恢复";self.message=@"正在校验备份和当前配置…";
    NSMutableSet *modules=[NSMutableSet set],*accounts=[NSMutableSet set];
    for(NSDictionary *f in self.snapshot[@"fields"]){NSDictionary *entry=[CSBackupRegistry entryForDomain:f[@"domain"] key:f[@"key"]];[modules addObject:entry[@"module"]];if([f[@"key"] isEqual:@"com.wechat.enhance.chat_group.account_profiles"]&&[f[@"value"] isKindOfClass:NSDictionary.class])[accounts addObjectsFromArray:[f[@"value"] allKeys]];}
    if([self.snapshot[@"source"][@"accounts"] isKindOfClass:NSArray.class])[accounts addObjectsFromArray:self.snapshot[@"source"][@"accounts"]];
    NSString *current=[CSBackupManager.sharedManager currentContext][@"account"];
    if(current.length)[accounts addObject:current];self.modules=[modules.allObjects sortedArrayUsingSelector:@selector(compare:)];self.accounts=[accounts.allObjects sortedArrayUsingSelector:@selector(compare:)];
    self.selectedModules=[modules mutableCopy];self.selectedAccounts=[NSMutableSet set];if(current.length)[self.selectedAccounts addObject:current];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"准备恢复" style:UIBarButtonItemStyleDone target:self action:@selector(confirm)];[self refreshPreview];
}
- (void)refreshPreview {
    NSUInteger generation=++self.generation;self.busy=YES;self.navigationItem.rightBarButtonItem.enabled=NO;
    [CSBackupManager.sharedManager preview:self.snapshot modules:self.selectedModules.copy accounts:self.selectedAccounts.copy completion:^(NSDictionary *preview,NSError *error){
        if(generation!=self.generation)return;self.busy=NO;self.preview=preview;self.message=error.localizedDescription?:[self describe:preview];self.navigationItem.rightBarButtonItem.enabled=preview!=nil;[self.tableView reloadData];
    }];
}
- (NSString *)describe:(NSDictionary *)preview {
    NSDateFormatter *date=[NSDateFormatter new];date.dateStyle=NSDateFormatterMediumStyle;date.timeStyle=NSDateFormatterShortStyle;
    NSMutableString *text=[NSMutableString stringWithFormat:@"%@\n创建于 %@ · 来源版本 %@\n%lu 项将变化 · %lu 张图片\n未选中的模块和账号保持当前配置。",self.snapshot[@"name"],[date stringFromDate:self.snapshot[@"createdAt"]],self.snapshot[@"source"][@"pluginVersion"],(unsigned long)[preview[@"changes"] count],(unsigned long)[self.snapshot[@"assets"] count]];
    for(NSString *warning in preview[@"warnings"])[text appendFormat:@"\n\n%@",warning];
    return text;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {(void)tableView;return 4;}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {(void)tableView;return section==0?1:(section==1?self.modules.count:(section==2?self.accounts.count:MAX(1,[self.preview[@"changes"] count])));}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {(void)tableView;return @[@"恢复概览",@"选择模块",@"选择原所属账号",@"变更明细"][section];}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {(void)tableView;if(section==2)return @"默认选择当前账号。其他账号的分组始终写回原账号，不会转移给当前账号。联系人和群关系仅支持同一本机、同一当前账号恢复。";if(section==3)return @"确认后会先保存当前配置的保护备份。重新打开微信时应用，期间配置变化会使计划失效。微信消息、账号、支付统计和已处理事件不在恢复范围。";return nil;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    (void)tableView;UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];cell.textLabel.numberOfLines=0;cell.detailTextLabel.numberOfLines=0;
    if(path.section==0){cell.textLabel.text=self.message;cell.selectionStyle=UITableViewCellSelectionStyleNone;}
    else if(path.section==1){NSString *module=self.modules[path.row];cell.textLabel.text=[CSBackupRegistry moduleTitles][module]?:module;cell.accessoryType=[self.selectedModules containsObject:module]?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;}
    else if(path.section==2){NSString *account=self.accounts[path.row];cell.textLabel.text=account;cell.detailTextLabel.text=[account isEqual:[CSBackupManager.sharedManager currentContext][@"account"]]?@"当前账号":@"其他已存档账号";cell.accessoryType=[self.selectedAccounts containsObject:account]?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;}
    else {
        NSArray *changes=self.preview[@"changes"];if(!changes.count){cell.textLabel.text=self.busy?@"正在校验…":@"所选范围没有差异";return cell;}
        NSDictionary *change=changes[path.row];NSString *key=change[@"key"],*module=change[@"module"];cell.textLabel.text=[CSBackupRegistry moduleTitles][module];
        NSDictionary *labels=@{@"com.wechat.enhance.redenvelop.autoReceive":@"自动领取红包",@"com.wechat.enhance.redenvelop.autoReplyEnable":@"红包自动回复",@"kReceiveTransferAutoEnableKey":@"自动收款",@"kReceiveTransferAutoReplyEnableKey":@"收款自动回复",@"com.wechat.enhance.chat_group.account_profiles":@"账号分组和成员"};
        NSString *label=labels[key]?:@"配置项";id before=change[@"before"][@"value"],after=change[@"after"][@"value"];
        if([change[@"reset"] boolValue])cell.detailTextLabel.text=[label stringByAppendingString:@"：恢复未设置状态"];
        else if([after isKindOfClass:NSNumber.class])cell.detailTextLabel.text=[NSString stringWithFormat:@"%@：%@ → %@",label,before?:@"未设置",after];
        else if([key isEqual:@"com.wechat.enhance.chat_group.account_profiles"]){NSMutableArray *removed=[NSMutableArray array];for(NSString *account in before){NSMutableSet *ids=[NSMutableSet set];for(NSDictionary *tab in after[account][@"customTabs"])[ids addObject:tab[@"id"]];for(NSDictionary *tab in before[account][@"customTabs"])if(![ids containsObject:tab[@"id"]])[removed addObject:tab[@"name"]];}cell.detailTextLabel.text=removed.count?[NSString stringWithFormat:@"账号分组将更新；移除分组：%@",[removed componentsJoinedByString:@"、"]]:@"更新所选账号的分组、成员和排序";}
        else if([after isKindOfClass:NSString.class]&&![after hasPrefix:@"csbackup:"])cell.detailTextLabel.text=[NSString stringWithFormat:@"%@：%@",label,[after length]>80?[[after substringToIndex:80]stringByAppendingString:@"…"]:after];
        else cell.detailTextLabel.text=[label stringByAppendingString:@"：替换为备份中的值"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];if(path.section!=1&&path.section!=2)return;NSMutableSet *selected=path.section==1?self.selectedModules:self.selectedAccounts;NSString *value=(path.section==1?self.modules:self.accounts)[path.row];if([selected containsObject:value])[selected removeObject:value];else [selected addObject:value];[tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationNone];[self refreshPreview];
}
- (void)confirm {
    if(self.busy||!self.preview)return;
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"准备恢复所选配置" message:@"先保存恢复前保护备份，再生成待执行计划。请随后手动退出并重新打开微信；现在不会修改当前设置。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"准备恢复" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action){self.busy=YES;self.tableView.userInteractionEnabled=NO;self.navigationItem.rightBarButtonItem.enabled=NO;[CSBackupManager.sharedManager prepare:self.preview completion:^(__unused id result,NSError *error){self.busy=NO;self.tableView.userInteractionEnabled=YES;UIAlertController *resultAlert=[UIAlertController alertControllerWithTitle:error?@"未能准备恢复":@"恢复已准备" message:error.localizedDescription?:@"请手动退出并重新打开微信后应用。可在备份页取消待恢复计划。" preferredStyle:UIAlertControllerStyleAlert];[resultAlert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){if(!error)[self.navigationController popViewControllerAnimated:YES];else [self refreshPreview];}]];[self presentViewController:resultAlert animated:YES completion:nil];}];}]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
