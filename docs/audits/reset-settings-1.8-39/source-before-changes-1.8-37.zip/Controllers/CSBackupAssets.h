#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface CSBackupAssets : NSObject
+ (nullable NSArray<NSDictionary *> *)captureFields:(NSArray<NSDictionary *> *)fields root:(NSURL *)root assets:(NSMutableDictionary<NSString *,NSData *> *)assets error:(NSError **)error;
+ (nullable NSArray<NSDictionary *> *)materializeFields:(NSArray<NSDictionary *> *)fields assets:(NSDictionary<NSString *,NSData *> *)assets root:(NSURL *)root writes:(NSMutableDictionary *)writes error:(NSError **)error;
+ (BOOL)validImage:(NSData *)data;
@end
NS_ASSUME_NONNULL_END
