#import <Foundation/Foundation.h>
#import <math.h>

// Appearance preferences follow the existing global group colors and haptics.
static NSString *const CSGroupTabFontSizeKey = @"com.wechat.enhance.chat_group.tab_font_size";
static NSString *const CSGroupSearchButtonVisibleKey = @"com.wechat.enhance.chat_group.show_search_button";
static NSString *const CSGroupIndicatorAnimationEnabledKey = @"com.wechat.enhance.chat_group.indicator_animation_enabled";
static NSString *const CSGroupIndicatorAnimationStyleKey = @"com.wechat.enhance.chat_group.indicator_animation_style";
typedef NS_ENUM(NSInteger, CSGroupIndicatorAnimationStyle) {
    CSGroupIndicatorAnimationNone = 0,
    CSGroupIndicatorAnimationClassic = 1,
    CSGroupIndicatorAnimationFluid = 2,
    CSGroupIndicatorAnimationSpring = 3,
    CSGroupIndicatorAnimationArc = 4,
};
static NSInteger const CSGroupDefaultTabFontSize = 18;
static NSInteger const CSGroupMinTabFontSize = 12;
static NSInteger const CSGroupMaxTabFontSize = 28;

NS_INLINE NSInteger CSGroupTabFontSize(NSUserDefaults *defaults) {
    id stored = [defaults objectForKey:CSGroupTabFontSizeKey];
    if (![stored isKindOfClass:NSNumber.class]) return CSGroupDefaultTabFontSize;
    double size = [stored doubleValue];
    if (!isfinite(size) || size < CSGroupMinTabFontSize || size > CSGroupMaxTabFontSize || floor(size) != size)
        return CSGroupDefaultTabFontSize;
    return (NSInteger)size;
}

NS_INLINE BOOL CSGroupSearchButtonVisible(NSUserDefaults *defaults) {
    id stored = [defaults objectForKey:CSGroupSearchButtonVisibleKey];
    return [stored isKindOfClass:NSNumber.class] ? [stored boolValue] : YES;
}

NS_INLINE CSGroupIndicatorAnimationStyle CSGroupIndicatorStyle(NSUserDefaults *defaults) {
    id value = [defaults objectForKey:CSGroupIndicatorAnimationStyleKey];
    if ([value isKindOfClass:NSNumber.class]) {
        double style = [value doubleValue];
        if (isfinite(style) && floor(style) == style && style >= CSGroupIndicatorAnimationNone && style <= CSGroupIndicatorAnimationArc)
            return (CSGroupIndicatorAnimationStyle)style;
    }
    // Read old preferences without rewriting them during layout or gestures.
    id stored = [defaults objectForKey:CSGroupIndicatorAnimationEnabledKey];
    return [stored isKindOfClass:NSNumber.class] && ![stored boolValue] ? CSGroupIndicatorAnimationNone : CSGroupIndicatorAnimationClassic;
}

NS_INLINE BOOL CSGroupIndicatorAnimationEnabled(NSUserDefaults *defaults) {
    return CSGroupIndicatorStyle(defaults) != CSGroupIndicatorAnimationNone;
}

NS_INLINE NSString *CSGroupIndicatorStyleName(CSGroupIndicatorAnimationStyle style) {
    switch (style) {
        case CSGroupIndicatorAnimationNone: return @"关闭";
        case CSGroupIndicatorAnimationFluid: return @"流体牵引";
        case CSGroupIndicatorAnimationSpring: return @"轻弹滑行";
        case CSGroupIndicatorAnimationArc: return @"微弧跃迁";
        default: return @"经典收缩";
    }
}

NS_INLINE void CSGroupSetIndicatorStyle(NSUserDefaults *defaults, CSGroupIndicatorAnimationStyle style) {
    if (style < CSGroupIndicatorAnimationNone || style > CSGroupIndicatorAnimationArc) style = CSGroupIndicatorAnimationClassic;
    [defaults setInteger:style forKey:CSGroupIndicatorAnimationStyleKey];
    // Keep downgrades compatible with the original on/off setting.
    [defaults setBool:style != CSGroupIndicatorAnimationNone forKey:CSGroupIndicatorAnimationEnabledKey];
}
