#import <CoreGraphics/CoreGraphics.h>
#import "CSGroupAppearance.h"

NS_INLINE NSTimeInterval CSGroupIndicatorMotionDuration(CSGroupIndicatorAnimationStyle style) {
    switch (style) {
        case CSGroupIndicatorAnimationFluid:
        case CSGroupIndicatorAnimationArc: return 0.36;
        case CSGroupIndicatorAnimationSpring: return 0.32;
        default: return 0.20;
    }
}

// Shared by finger-driven previews and bounded Core Animation keyframes.
NS_INLINE CGRect CSGroupIndicatorMotionFrame(CGRect from, CGRect to, CGFloat progress, CSGroupIndicatorAnimationStyle style) {
    CGFloat t = isfinite(progress) ? MAX(0, MIN(1, progress)) : 0;
    if (style == CSGroupIndicatorAnimationNone) return to;
    if (t == 0) return from;
    if (t == 1) return to;
    CGFloat center = CGRectGetMidX(from) + (CGRectGetMidX(to) - CGRectGetMidX(from)) * t;
    CGFloat centerY = CGRectGetMidY(from) + (CGRectGetMidY(to) - CGRectGetMidY(from)) * t;
    CGFloat width = from.size.width + (to.size.width - from.size.width) * t;
    CGFloat height = from.size.height + (to.size.height - from.size.height) * t;
    CGFloat wave = sin(M_PI * t);
    switch (style) {
        case CSGroupIndicatorAnimationFluid: {
            CGFloat head = sin(t * M_PI_2), tail = 1 - cos(t * M_PI_2);
            BOOL right = CGRectGetMidX(to) >= CGRectGetMidX(from);
            CGFloat left = CGRectGetMinX(from) + (CGRectGetMinX(to) - CGRectGetMinX(from)) * (right ? tail : head);
            CGFloat end = CGRectGetMaxX(from) + (CGRectGetMaxX(to) - CGRectGetMaxX(from)) * (right ? head : tail);
            center = (left + end) / 2;
            width = end - left;
            break;
        }
        case CSGroupIndicatorAnimationSpring: {
            CGFloat z = t - 1, eased = 1 + 1.65 * z * z * z + 0.65 * z * z;
            center = CGRectGetMidX(from) + (CGRectGetMidX(to) - CGRectGetMidX(from)) * eased;
            width += 6 * wave * wave;
            break;
        }
        case CSGroupIndicatorAnimationArc:
            center = CGRectGetMidX(from) + (CGRectGetMidX(to) - CGRectGetMidX(from)) * t * t * (3 - 2 * t);
            width *= 1 - 0.55 * wave * wave;
            centerY -= 7 * wave;
            height += wave;
            break;
        default: {
            // Preserve the classic gesture: shortest beneath the destination,
            // then expand in place, including unequal title widths.
            center = CGRectGetMidX(from) + (CGRectGetMidX(to) - CGRectGetMidX(from)) * MIN(1, t * 2);
            CGFloat minimumWidth = MIN(from.size.width, to.size.width) * 0.30;
            CGFloat endpointWidth = t < 0.5 ? from.size.width : to.size.width;
            width = endpointWidth + (minimumWidth - endpointWidth) * wave;
            break;
        }
    }
    return CGRectMake(center - width / 2, centerY - height / 2, width, height);
}
