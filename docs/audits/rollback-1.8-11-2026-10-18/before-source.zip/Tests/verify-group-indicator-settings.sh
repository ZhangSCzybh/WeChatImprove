#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
test_dir="$(mktemp -d "${TMPDIR:-/tmp}/wechat-group-indicator-settings.XXXXXX")"
trap 'rm -rf "$test_dir"' EXIT
python3 - "$project_dir" "$test_dir" <<'PY'
from pathlib import Path
import sys
source=(Path(sys.argv[1])/'Controllers/CSChatGroupSettingsViewController.m').read_text()
start=source.index('- (void)showIndicatorAnimationPicker {')
brace=source.index('{',start); depth=0
for end in range(brace,len(source)):
    if source[end]=='{': depth+=1
    elif source[end]=='}':
        depth-=1
        if not depth: break
(Path(sys.argv[2])/'GroupIndicatorPickerBody.h').write_text(source[start:end+1])
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
    -framework Foundation -framework CoreGraphics -I"$test_dir" \
    "$project_dir/Tests/GroupIndicatorSettingsTests.m" -o "$test_dir/settings-tests"
"$test_dir/settings-tests"
