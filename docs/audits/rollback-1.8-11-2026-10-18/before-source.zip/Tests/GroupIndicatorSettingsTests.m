#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import "../Controllers/CSGroupAppearance.h"

// Replay the production picker against an isolated suite and minimal UIKit doubles.
static NSUserDefaults *testDefaults;
static BOOL usePopover;
@interface IndicatorSettingsDefaults : NSUserDefaults
+ (instancetype)standardUserDefaults;
@end
@implementation IndicatorSettingsDefaults
+ (instancetype)standardUserDefaults { return (id)testDefaults; }
@end
@interface TestView : NSObject
@property(nonatomic) CGRect bounds;
@property(nonatomic) NSUInteger reloads;
- (void)reloadData;
@end
@implementation TestView
- (void)reloadData { self.reloads++; }
@end
@interface UIPopoverPresentationController : NSObject
@property(nonatomic,strong) TestView *sourceView;
@property(nonatomic) CGRect sourceRect;
@property(nonatomic) NSUInteger permittedArrowDirections;
@end
@implementation UIPopoverPresentationController @end
enum { UIAlertControllerStyleActionSheet, UIAlertActionStyleDefault, UIAlertActionStyleCancel };
@interface UIAlertAction : NSObject
@property(nonatomic,copy) NSString *title;
@property(nonatomic) NSInteger style;
@property(nonatomic,copy) void (^handler)(UIAlertAction *);
+ (instancetype)actionWithTitle:(NSString *)title style:(NSInteger)style handler:(void (^)(UIAlertAction *))handler;
@end
@implementation UIAlertAction
+ (instancetype)actionWithTitle:(NSString *)title style:(NSInteger)style handler:(void (^)(UIAlertAction *))handler {
    UIAlertAction *a=[self new]; a.title=title; a.style=style; a.handler=handler; return a;
}
@end
@interface UIAlertController : NSObject
@property(nonatomic,copy) NSString *title,*message;
@property(nonatomic) NSInteger preferredStyle;
@property(nonatomic,strong) NSMutableArray<UIAlertAction *> *actions;
@property(nonatomic,strong) UIPopoverPresentationController *popoverPresentationController;
+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(NSInteger)style;
- (void)addAction:(UIAlertAction *)action;
@end
@implementation UIAlertController
+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(NSInteger)style {
    UIAlertController *a=[self new]; a.title=title; a.message=message; a.preferredStyle=style; a.actions=[NSMutableArray array];
    if (usePopover) a.popoverPresentationController=[UIPopoverPresentationController new]; return a;
}
- (void)addAction:(UIAlertAction *)action { [self.actions addObject:action]; }
@end
@interface SettingsController : NSObject
@property(nonatomic,strong) TestView *view,*tableView;
@property(nonatomic,strong) UIAlertController *presented;
@property(nonatomic) NSUInteger settingsReloads,dataReloads;
- (void)reloadChatGroupSettings;
- (void)setupData;
- (void)presentViewController:(UIAlertController *)alert animated:(BOOL)animated completion:(void (^)(void))completion;
@end
@implementation SettingsController
- (instancetype)init { if ((self=[super init])) { _view=[TestView new]; _view.bounds=CGRectMake(0,0,768,1024); _tableView=[TestView new]; } return self; }
- (void)reloadChatGroupSettings { self.settingsReloads++; }
- (void)setupData { self.dataReloads++; }
- (void)presentViewController:(UIAlertController *)alert animated:(BOOL)animated completion:(void (^)(void))completion {
    (void)animated; self.presented=alert; if (completion) completion();
}
#define NSUserDefaults IndicatorSettingsDefaults
#include "GroupIndicatorPickerBody.h"
#undef NSUserDefaults
@end
static NSUInteger checks,failures;
static void Check(BOOL condition,NSString *message) { checks++; if (!condition) { failures++; fprintf(stderr,"FAIL: %s\n",message.UTF8String); } }
int main(void) { @autoreleasepool {
    NSString *suite=[@"com.wechat.improve.tests.indicator-settings." stringByAppendingString:NSUUID.UUID.UUIDString];
    testDefaults=[[NSUserDefaults alloc] initWithSuiteName:suite];
    Check(CSGroupIndicatorStyle(testDefaults)==CSGroupIndicatorAnimationClassic,@"unset preferences preserve classic animation");
    Check(![testDefaults objectForKey:CSGroupIndicatorAnimationStyleKey] && ![testDefaults objectForKey:CSGroupIndicatorAnimationEnabledKey],@"reading a style does not write preferences");
    for (NSNumber *enabled in @[@NO,@YES]) {
        [testDefaults setObject:enabled forKey:CSGroupIndicatorAnimationEnabledKey];
        CSGroupIndicatorAnimationStyle expected=enabled.boolValue?CSGroupIndicatorAnimationClassic:CSGroupIndicatorAnimationNone;
        Check(CSGroupIndicatorStyle(testDefaults)==expected,@"legacy enabled and disabled preferences survive upgrade");
        for (id invalid in @[@"2",@(-1),@5,@1.25,@(NAN),@{},@[]]) {
            [testDefaults setObject:invalid forKey:CSGroupIndicatorAnimationStyleKey];
            Check(CSGroupIndicatorStyle(testDefaults)==expected,@"invalid new style falls back to the legacy preference");
        }
        [testDefaults removeObjectForKey:CSGroupIndicatorAnimationStyleKey];
    }
    NSArray<NSNumber *> *choices=@[@1,@2,@3,@4,@0];
    NSArray<NSString *> *names=@[@"经典收缩",@"流体牵引",@"轻弹滑行",@"微弧跃迁",@"关闭"];
    for (NSUInteger i=0;i<choices.count;i++) {
        CSGroupIndicatorAnimationStyle style=choices[i].integerValue;
        CSGroupSetIndicatorStyle(testDefaults,style);
        Check(CSGroupIndicatorStyle([[NSUserDefaults alloc] initWithSuiteName:suite])==style &&
              [CSGroupIndicatorStyleName(style) isEqual:names[i]],@"all styles persist and map to the intended labels");
        Check([testDefaults boolForKey:CSGroupIndicatorAnimationEnabledKey]==(style!=CSGroupIndicatorAnimationNone),@"saving a style retains downgrade-compatible legacy state");
        [testDefaults setBool:style==CSGroupIndicatorAnimationNone forKey:CSGroupIndicatorAnimationEnabledKey];
        Check(CSGroupIndicatorStyle(testDefaults)==style && CSGroupIndicatorAnimationEnabled(testDefaults)==(style!=CSGroupIndicatorAnimationNone),@"explicit style takes precedence over a conflicting legacy switch");
        usePopover=i%2==0;
        SettingsController *c=[SettingsController new]; [c showIndicatorAnimationPicker];
        UIAlertController *a=c.presented;
        Check(a.actions.count==6 && [a.title isEqual:@"分组指示器切换动画"] && a.preferredStyle==UIAlertControllerStyleActionSheet,@"picker offers five styles and cancel");
        BOOL labels=YES;
        for (NSUInteger j=0;j<5;j++) labels &= [a.actions[j].title isEqual:j==i?[names[j] stringByAppendingString:@" ✓"]:names[j]];
        Check(labels,@"picker order and checkmark correspond to the stored style");
        UIAlertAction *cancel=a.actions.lastObject;
        Check(cancel.style==UIAlertActionStyleCancel && !cancel.handler && c.settingsReloads==0 && CSGroupIndicatorStyle(testDefaults)==style,@"opening and cancelling the picker do not mutate settings");
        if (usePopover) Check(a.popoverPresentationController.sourceView==c.view && !CGRectIsEmpty(a.popoverPresentationController.sourceRect),@"tablet action sheet has a valid popover anchor");
        // Choose a different entry so this checks every handler's captured value.
        NSUInteger next=(i+1)%choices.count;
        UIAlertAction *action=a.actions[next]; action.handler(action);
        Check(CSGroupIndicatorStyle(testDefaults)==choices[next].integerValue &&
              [testDefaults boolForKey:CSGroupIndicatorAnimationEnabledKey]==(choices[next].integerValue!=0),@"each picker action saves its own style with compatible old state");
        Check(c.settingsReloads==1 && c.dataReloads==1 && c.tableView.reloads==1,@"selection publishes exactly one settings refresh and updates the displayed value");
    }
    CSGroupSetIndicatorStyle(testDefaults,(CSGroupIndicatorAnimationStyle)99);
    Check(CSGroupIndicatorStyle(testDefaults)==CSGroupIndicatorAnimationClassic,@"invalid writer input safely selects classic");
    [testDefaults removePersistentDomainForName:suite];
    printf("Group indicator settings: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures?1:0;
} }
