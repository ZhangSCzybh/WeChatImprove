#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <math.h>
#import "../Controllers/CSGroupIndicatorMotion.h"
// Redirect only this host replay to an isolated preference suite.
static NSUserDefaults *testDefaults;
@interface IndicatorTestDefaults : NSUserDefaults
@end
@implementation IndicatorTestDefaults
+ (NSUserDefaults *)standardUserDefaults { return testDefaults; }
@end
static NSUInteger viewportAnimations;
@interface NSValue (UIKitGeometry)
+ (instancetype)valueWithCGPoint:(CGPoint)value;
+ (instancetype)valueWithCGSize:(CGSize)value;
- (CGPoint)CGPointValue;
- (CGSize)CGSizeValue;
@end
@implementation NSValue (UIKitGeometry)
+ (instancetype)valueWithCGPoint:(CGPoint)value { return [self valueWithBytes:&value objCType:@encode(CGPoint)]; }
+ (instancetype)valueWithCGSize:(CGSize)value { return [self valueWithBytes:&value objCType:@encode(CGSize)]; }
- (CGSize)CGSizeValue { CGSize size; [self getValue:&size size:sizeof(size)]; return size; }
- (CGPoint)CGPointValue { CGPoint point; [self getValue:&point size:sizeof(point)]; return point; }
@end
static BOOL reducedMotion;
static BOOL UIAccessibilityIsReduceMotionEnabled(void) { return reducedMotion; }
static CGFloat const kIndicatorHeight=2;
static NSTimeInterval const kIndicatorDuration=0.20;
static NSString *const kIndicatorAnimationKey=@"CSGroupIndicator.selection";
enum { UIViewAnimationOptionCurveEaseInOut=1, UIViewAnimationOptionBeginFromCurrentState=2, UIViewAnimationOptionAllowUserInteraction=4 };
@interface TestLayer : CALayer
@property(nonatomic,strong) NSMutableDictionary *savedAnimations;
@property(nonatomic,strong) CALayer *visibleLayer;
@property(nonatomic) NSUInteger animationAdds;
@end
@implementation TestLayer
- (instancetype)init { if ((self=[super init])) _savedAnimations=[NSMutableDictionary dictionary]; return self; }
- (instancetype)presentationLayer { return (id)self.visibleLayer; }
- (CAAnimation *)animationForKey:(NSString *)key { return self.savedAnimations[key]; }
- (void)addAnimation:(CAAnimation *)animation forKey:(NSString *)key { self.savedAnimations[key]=animation; self.animationAdds++; }
- (void)removeAnimationForKey:(NSString *)key { [self.savedAnimations removeObjectForKey:key]; }
@end
@interface UIView : NSObject
@property(nonatomic,strong) TestLayer *layer;
@property(nonatomic) BOOL hidden;
@property(nonatomic,strong) id window;
@property(nonatomic) CGRect frame,bounds;
@property(nonatomic) CGPoint contentOffset;
@property(nonatomic) CGSize contentSize;
@property(nonatomic) NSUInteger scrollWrites;
- (void)layoutIfNeeded;
- (void)setContentOffset:(CGPoint)offset animated:(BOOL)animated;
+ (void)animateWithDuration:(double)duration delay:(double)delay options:(NSUInteger)options animations:(void (^)(void))animations completion:(void (^)(BOOL))completion;
@end
@implementation UIView
- (instancetype)init { if ((self=[super init])) _layer=[TestLayer layer]; return self; }
- (CGRect)frame { return self.layer.frame; }
- (void)setFrame:(CGRect)frame { self.layer.frame=frame; }
- (void)layoutIfNeeded {}
- (void)setContentOffset:(CGPoint)offset animated:(BOOL)animated { (void)animated; self.contentOffset=offset; self.scrollWrites++; }
+ (void)animateWithDuration:(double)duration delay:(double)delay options:(NSUInteger)options animations:(void (^)(void))animations completion:(void (^)(BOOL))completion {
    (void)duration; (void)delay; (void)options; viewportAnimations++; animations(); if (completion) completion(YES);
}
@end
@interface WETabButton : UIView
@property(nonatomic) NSInteger tabIndex;
@property(nonatomic,copy) NSString *tabID;
@property(nonatomic) CGRect titleFrame;
- (CGRect)tabTitleFrame;
@end
@implementation WETabButton
- (CGRect)tabTitleFrame { return CGRectIsEmpty(self.titleFrame) ? CGRectMake(20,12,40,20) : self.titleFrame; }
@end
@interface WESessionTabContainerView : UIView
@property(nonatomic) NSInteger selectedIndex;
@property(nonatomic,copy) NSString *selectedTabID;
@property(nonatomic,strong) NSArray<WETabButton *> *tabButtons;
@property(nonatomic,strong) UIView *indicatorView,*scrollView;
@property(nonatomic) NSUInteger haptics;
@property(nonatomic) BOOL interactiveTransition,settlingInteractiveTransition;
@property(nonatomic) NSInteger interactiveTarget;
@property(nonatomic) CGFloat interactiveProgress;
@property(nonatomic) CSGroupIndicatorAnimationStyle renderedIndicatorStyle;
- (CGRect)indicatorFrameForIndex:(NSInteger)index;
- (void)updateInteractiveTransitionToIndex:(NSInteger)index progress:(CGFloat)progress;
- (void)cancelInteractiveTransition;
- (void)selectTabAtIndex:(NSInteger)index animated:(BOOL)animated;
- (void)updateIndicatorPosition;
- (void)updateIndicatorPositionAnimated:(BOOL)animated;
- (void)moveIndicatorToFrame:(CGRect)frame animated:(BOOL)animated;
- (void)scrollToSelectedTab;
@end
@implementation WESessionTabContainerView
#define NSUserDefaults IndicatorTestDefaults
#include "GroupIndicatorBodies.h"
#undef NSUserDefaults
- (void)triggerHapticFeedback { self.haptics++; }
- (void)updateSelectedButtons {}
@end
static NSUInteger checks,failures;
static void Check(BOOL c,NSString *message) { checks++; if (!c) { failures++; fprintf(stderr,"FAIL: %s\n",message.UTF8String); } }
static WESessionTabContainerView *Fixture(void) {
    WESessionTabContainerView *view=[WESessionTabContainerView new];
    view.window=[NSObject new]; view.indicatorView=[UIView new]; view.scrollView=[UIView new];
    view.scrollView.bounds=CGRectMake(0,0,160,52); view.scrollView.contentSize=CGSizeMake(300,52);
    NSMutableArray *buttons=[NSMutableArray array];
    for (NSInteger i=0;i<3;i++) {
        WETabButton *button=[WETabButton new]; button.frame=CGRectMake(i*100,0,80,52);
        button.bounds=CGRectMake(0,0,80,52); button.tabIndex=i; button.tabID=[NSString stringWithFormat:@"tab%ld",(long)i];
        [buttons addObject:button];
    }
    view.tabButtons=buttons; view.selectedIndex=0; view.selectedTabID=@"tab0";
    [view updateIndicatorPositionAnimated:NO]; return view;
}
static void TestSwipeGeometry(void) {
    // Different title widths must reach their minimum at the destination too.
    for (NSArray<NSNumber *> *widths in @[@[@40,@40],@[@40,@140],@[@140,@40]]) {
        for (NSInteger direction=0;direction<2;direction++) {
            WESessionTabContainerView *view=Fixture();
            for (NSUInteger index=0;index<2;index++) {
                WETabButton *button=view.tabButtons[index];
                CGFloat width=widths[index].doubleValue;
                button.frame=CGRectMake(index*200,0,width+40,52);
                button.bounds=CGRectMake(0,0,width+40,52);
                button.titleFrame=CGRectMake(20,12,width,20);
            }
            [view selectTabAtIndex:direction animated:NO];
            CGRect origin=[view indicatorFrameForIndex:direction], target=[view indicatorFrameForIndex:1-direction];
            CGFloat previousWidth=origin.size.width, minimumWidth=CGFLOAT_MAX, minimumCenter=0;
            BOOL contracts=YES,expands=YES,staysAtTarget=YES,bounded=YES,reversible=YES;
            NSMutableArray<NSValue *> *frames=[NSMutableArray array];
            for (NSUInteger step=0;step<=100;step++) {
                [view updateInteractiveTransitionToIndex:1-direction progress:step/100.0];
                CGRect frame=view.indicatorView.frame;
                [frames addObject:[NSValue valueWithBytes:&frame objCType:@encode(CGRect)]];
                if (step<=50) contracts &= frame.size.width<=previousWidth+0.001;
                else expands &= frame.size.width>=previousWidth-0.001;
                if (step>=50) staysAtTarget &= fabs(CGRectGetMidX(frame)-CGRectGetMidX(target))<0.001;
                bounded &= frame.size.width>=MIN(origin.size.width,target.size.width)*0.30-0.001 &&
                    frame.size.width<=MAX(origin.size.width,target.size.width)+0.001;
                if (frame.size.width<minimumWidth) { minimumWidth=frame.size.width; minimumCenter=CGRectGetMidX(frame); }
                previousWidth=frame.size.width;
            }
            Check(contracts && expands,@"both swipe directions contract then expand even with unequal title widths");
            Check(staysAtTarget && fabs(minimumCenter-CGRectGetMidX(target))<0.001,@"minimum width is under the target title and expansion stays there");
            Check(bounded && CGRectEqualToRect(view.indicatorView.frame,target),@"swipe preserves width bounds and ends at the normal target frame");
            for (NSInteger step=100;step>=0;step--) {
                [view updateInteractiveTransitionToIndex:1-direction progress:step/100.0];
                CGRect expected; [frames[step] getValue:&expected size:sizeof(expected)];
                reversible &= CGRectEqualToRect(view.indicatorView.frame,expected);
            }
            Check(reversible && CGRectEqualToRect(view.indicatorView.frame,origin),@"finger reversal retraces the same geometry back to the source");
            [view updateInteractiveTransitionToIndex:1-direction progress:0.75];
            [view cancelInteractiveTransition];
            Check(view.selectedIndex==direction && CGRectEqualToRect(view.indicatorView.frame,origin),@"cancel after arriving under the target still restores the original group");
        }
    }
}
static BOOL Near(CGFloat a, CGFloat b) { return fabs(a-b)<0.001; }
static void TestAnimationStyles(void) {
    for (CSGroupIndicatorAnimationStyle style=CSGroupIndicatorAnimationFluid;style<=CSGroupIndicatorAnimationArc;style++) {
        CSGroupSetIndicatorStyle(testDefaults,style);
        for (NSInteger direction=0;direction<2;direction++) {
            CGRect a=CGRectMake(10,45,52,2),b=CGRectMake(210,45,112,2);
            if (direction) { CGRect swap=a; a=b; b=swap; }
            Check(CGRectEqualToRect(CSGroupIndicatorMotionFrame(a,b,0,style),a) &&
                  CGRectEqualToRect(CSGroupIndicatorMotionFrame(a,b,1,style),b),@"new curves preserve exact unequal-width endpoints in both directions");
            BOOL finite=YES,reversible=YES;
            for (NSUInteger step=0;step<=100;step++) {
                CGRect f=CSGroupIndicatorMotionFrame(a,b,step/100.0,style);
                finite &= isfinite(f.origin.x) && isfinite(f.origin.y) && f.size.width>0 && f.size.height>0;
                CGRect reverse=CSGroupIndicatorMotionFrame(b,a,1-step/100.0,style);
                if (style!=CSGroupIndicatorAnimationSpring) reversible &= Near(f.origin.x,reverse.origin.x) && Near(f.size.width,reverse.size.width);
            }
            Check(finite && reversible,@"new curves stay finite with positive size and fluid/arc paths mirror in reverse");
            CGRect mid=CSGroupIndicatorMotionFrame(a,b,0.5,style);
            CGFloat baseWidth=(a.size.width+b.size.width)/2;
            if (style==CSGroupIndicatorAnimationFluid)
                Check(mid.size.width>MAX(a.size.width,b.size.width) && Near(mid.origin.y,45),@"fluid stretches between titles with its leading edge ahead");
            if (style==CSGroupIndicatorAnimationSpring) {
                CGRect late=CSGroupIndicatorMotionFrame(a,b,0.8,style);
                CGFloat overshoot=(CGRectGetMidX(late)-CGRectGetMidX(b))/(CGRectGetMidX(b)-CGRectGetMidX(a));
                Check(overshoot>0 && overshoot<0.02 && Near(mid.size.width,baseWidth+6),@"spring has a small bounded overshoot and gentle stretch");
            }
            if (style==CSGroupIndicatorAnimationArc)
                Check(Near(mid.size.width,baseWidth*0.45) && Near(CGRectGetMidY(mid),39) && Near(mid.size.height,3),@"arc lifts seven points while narrowing and slightly thickening");
        }
        WESessionTabContainerView *v=Fixture();
        CGRect origin=v.indicatorView.frame;
        [v selectTabAtIndex:1 animated:YES];
        CAAnimationGroup *group=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey];
        CAKeyframeAnimation *position=(id)group.animations[0],*size=(id)group.animations[1];
        Check(Near(group.duration,CSGroupIndicatorMotionDuration(style)) && group.repeatCount==0 && !group.autoreverses,@"each style plays once for its intended duration");
        Check(position.values.count==25 && size.values.count==25 && position.keyTimes.count==25 &&
              [position.calculationMode isEqual:kCAAnimationLinear],@"new click animation uses a bounded set of native keyframes");
        Check(Near([position.values.firstObject CGPointValue].x,CGRectGetMidX(origin)) &&
              Near([position.values.lastObject CGPointValue].x,140) &&
              CGSizeEqualToSize([size.values.lastObject CGSizeValue],v.indicatorView.frame.size),@"keyframes start at the source and end exactly at the model frame");
        [v updateIndicatorPosition]; [v selectTabAtIndex:1 animated:YES];
        Check(v.indicatorView.layer.animationAdds==1 && v.haptics==1,@"unchanged layout and selection preserve each new animation");
        CALayer *visible=[CALayer layer]; visible.frame=CSGroupIndicatorMotionFrame(origin,v.indicatorView.frame,0.4,style);
        v.indicatorView.layer.visibleLayer=visible;
        [v selectTabAtIndex:2 animated:YES];
        group=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey]; position=(id)group.animations[0]; size=(id)group.animations[1];
        Check(CGPointEqualToPoint([position.values.firstObject CGPointValue],visible.position) &&
              CGSizeEqualToSize([size.values.firstObject CGSizeValue],visible.bounds.size),@"rapid retarget preserves the presentation position, height and width");
        for (NSUInteger commit=0;commit<2;commit++) {
            v=Fixture();
            CGRect target=[v indicatorFrameForIndex:1];
            [v updateInteractiveTransitionToIndex:1 progress:0.43];
            CGRect finger=v.indicatorView.frame;
            Check(CGRectEqualToRect(finger,CSGroupIndicatorMotionFrame(origin,target,0.43,style)) && v.indicatorView.layer.animationAdds==0 && v.haptics==0,@"finger-driven styles use the same geometry without queued animations or selection commits");
            [v updateIndicatorPosition];
            Check(CGRectEqualToRect(v.indicatorView.frame,finger),@"layout preserves the current finger position");
            [v updateInteractiveTransitionToIndex:1 progress:0.21];
            Check(CGRectEqualToRect(v.indicatorView.frame,CSGroupIndicatorMotionFrame(origin,target,0.21,style)),@"reversing the finger retraces the same curve");
            finger=v.indicatorView.frame;
            if (commit) [v selectTabAtIndex:1 animated:YES]; else [v cancelInteractiveTransition];
            group=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey]; position=(id)group.animations[0]; size=(id)group.animations[1];
            Check(position.values.count==2 && size.values.count==2 && Near(group.duration,0.20),@"release and cancel settle directly without a second style cycle");
            Check(Near([position.values.firstObject CGPointValue].y,CGRectGetMidY(finger)) &&
                  CGSizeEqualToSize([size.values.firstObject CGSizeValue],finger.size) && v.selectedIndex==(NSInteger)commit &&
                  CGRectEqualToRect(v.indicatorView.frame,commit?target:origin),@"settle begins at finger geometry and commits or restores the correct group");
        }
        v=Fixture(); [v selectTabAtIndex:1 animated:YES];
        CSGroupSetIndicatorStyle(testDefaults,CSGroupIndicatorAnimationClassic); v.selectedTabID=@"tab1";
        Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey] && v.renderedIndicatorStyle==CSGroupIndicatorAnimationClassic,@"same-ID settings refresh stops the previous style immediately");
        CSGroupSetIndicatorStyle(testDefaults,style); [v selectTabAtIndex:0 animated:YES];
        Check([v.indicatorView.layer animationForKey:kIndicatorAnimationKey]!=nil,@"first new selection after changing a style can animate");
        [v updateInteractiveTransitionToIndex:1 progress:0.4];
        CSGroupSetIndicatorStyle(testDefaults,CSGroupIndicatorAnimationClassic); [v updateIndicatorPosition];
        Check(!v.interactiveTransition && CGRectEqualToRect(v.indicatorView.frame,origin),@"style refresh cancels an old gesture preview without selecting its target");
        CSGroupSetIndicatorStyle(testDefaults,style); v=Fixture(); reducedMotion=YES;
        [v updateInteractiveTransitionToIndex:1 progress:0.5]; [v selectTabAtIndex:1 animated:YES];
        Check(!v.interactiveTransition && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"reduce motion suppresses new styles for both gestures and taps");
        reducedMotion=NO; v=Fixture(); v.window=nil;
        [v updateInteractiveTransitionToIndex:1 progress:0.5]; [v selectTabAtIndex:1 animated:YES];
        Check(!v.interactiveTransition && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"offscreen views do not start any new style");
        v=Fixture(); [v selectTabAtIndex:1 animated:YES]; CSGroupSetIndicatorStyle(testDefaults,CSGroupIndicatorAnimationNone);
        [v updateIndicatorPosition]; [v updateInteractiveTransitionToIndex:2 progress:0.5]; [v selectTabAtIndex:2 animated:YES];
        Check(!v.interactiveTransition && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey] && v.selectedIndex==2,@"turning off a new style cancels it and retains functional switching");
    }
}
int main(void) { @autoreleasepool {
    NSString *suite=[@"com.wechat.improve.tests.indicator." stringByAppendingString:NSUUID.UUID.UUIDString];
    testDefaults=[[NSUserDefaults alloc] initWithSuiteName:suite];
    Check(CSGroupIndicatorAnimationEnabled(testDefaults),@"unset preference preserves enabled animation by default");
    [testDefaults setObject:@"invalid" forKey:CSGroupIndicatorAnimationEnabledKey];
    Check(CSGroupIndicatorAnimationEnabled(testDefaults),@"invalid stored preference falls back to enabled");
    [testDefaults removeObjectForKey:CSGroupIndicatorAnimationEnabledKey];
    WESessionTabContainerView *v=Fixture();
    [v selectTabAtIndex:1 animated:YES];
    CAAnimationGroup *first=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey];
    Check(first!=nil && fabs(first.duration-0.20)<0.001,@"user selection starts the intended transition");
    Check(v.selectedIndex==1 && [v.selectedTabID isEqual:@"tab1"],@"selection commits immediately without waiting for animation");
    NSUInteger adds=v.indicatorView.layer.animationAdds,haptics=v.haptics,scrolls=v.scrollView.scrollWrites;
    for (NSUInteger i=0;i<4;i++) { v.selectedTabID=@"tab1"; [v updateIndicatorPosition]; [v scrollToSelectedTab]; }
    Check([v.indicatorView.layer animationForKey:kIndicatorAnimationKey]==first,@"projection refresh and same-ID acknowledgement preserve the transition");
    Check(v.indicatorView.layer.animationAdds==adds && v.haptics==haptics,@"repeated publication neither restarts the animation nor repeats haptics");
    Check(v.scrollView.scrollWrites==scrolls,@"unchanged selected scroll target is not rewritten during animation");
    CALayer *visible=[CALayer layer]; visible.frame=CGRectMake(65,45,62,2);
    v.indicatorView.layer.visibleLayer=visible;
    [v selectTabAtIndex:2 animated:YES];
    CAAnimationGroup *next=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey];
    CAKeyframeAnimation *position=(id)next.animations[0];
    CGPoint start=[position.values[0] CGPointValue];
    Check(fabs(start.x-CGRectGetMidX(visible.frame))<0.001,@"rapid selection continues from the visible position");
    CGPoint end=[position.values.lastObject CGPointValue];
    Check(fabs(end.x-CGRectGetMidX(v.indicatorView.layer.frame))<0.001,@"model geometry already equals the final destination");
    CGRect oldTarget=v.indicatorView.layer.frame;
    WETabButton *button=v.tabButtons[2]; CGRect shifted=button.frame; shifted.origin.x+=18; button.frame=shifted;
    [v updateIndicatorPosition];
    Check(CGRectGetMinX(v.indicatorView.layer.frame)==CGRectGetMinX(oldTarget)+18 && v.indicatorView.layer.animationAdds==adds+2,@"changed badge/layout geometry retargets the moving indicator");
    reducedMotion=YES; [v selectTabAtIndex:0 animated:YES];
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey] && v.selectedIndex==0,@"reduce motion commits immediately and cancels movement");
    reducedMotion=NO; v=Fixture(); v.window=nil; [v selectTabAtIndex:2 animated:YES];
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"offscreen selection does not animate");
    v=Fixture(); v.indicatorView.hidden=YES; [v selectTabAtIndex:1 animated:YES];
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"first reveal does not fly in from stale geometry");
    v=Fixture(); [v selectTabAtIndex:2 animated:YES]; v.selectedIndex=NSNotFound; [v updateIndicatorPosition];
    Check(v.indicatorView.hidden && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"removing all tabs hides the indicator and clears animation");
    v=Fixture(); [v selectTabAtIndex:1 animated:YES]; [v selectTabAtIndex:0 animated:NO];
    Check(v.selectedIndex==0 && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"a genuinely different nonanimated selection can cancel and restore selection");
    v=Fixture(); [v selectTabAtIndex:-1 animated:YES]; [v selectTabAtIndex:8 animated:YES];
    Check(v.selectedIndex==0 && v.indicatorView.layer.animationAdds==0,@"invalid selection does not animate or alter selection");
    v=Fixture(); [v selectTabAtIndex:1 animated:YES];
    [testDefaults setBool:NO forKey:CSGroupIndicatorAnimationEnabledKey];
    Check(!CSGroupIndicatorAnimationEnabled([[NSUserDefaults alloc] initWithSuiteName:suite]),@"disabled preference survives a fresh preferences instance");
    v.selectedTabID=@"tab1";
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey] && v.selectedIndex==1,@"settings refresh cancels in-flight animation even for the same selected ID");
    NSUInteger viewportBefore=viewportAnimations;
    [v selectTabAtIndex:2 animated:YES];
    Check(v.selectedIndex==2 && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey] && viewportAnimations==viewportBefore,@"disabled switch commits taps/swipes without indicator or label viewport animation");
    Check(fabs(CGRectGetMidX(v.indicatorView.frame)-240)<0.001 && v.scrollView.contentOffset.x==140,@"disabled animation still places the indicator and reveals the selected tab");
    [testDefaults setBool:YES forKey:CSGroupIndicatorAnimationEnabledKey];
    [v selectTabAtIndex:0 animated:YES];
    Check([v.indicatorView.layer animationForKey:kIndicatorAnimationKey]!=nil,@"reenabling the switch restores the next selection animation");
    [testDefaults setBool:NO forKey:CSGroupIndicatorAnimationEnabledKey];
    [v updateIndicatorPosition];
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"layout refresh cannot retain an animation after disabling");
    [testDefaults setBool:YES forKey:CSGroupIndicatorAnimationEnabledKey];
    reducedMotion=YES; [v selectTabAtIndex:1 animated:YES];
    Check(![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"system reduce motion overrides the enabled switch");
    reducedMotion=NO; v=Fixture();
    CGRect origin=v.indicatorView.frame;
    [v updateInteractiveTransitionToIndex:1 progress:0.25];
    Check(v.interactiveTransition && v.selectedIndex==0 && v.haptics==0,@"drag preview never commits selection or sends haptics");
    Check(fabs(CGRectGetMidX(v.indicatorView.frame)-90)<0.001 && ![v.indicatorView.layer animationForKey:kIndicatorAnimationKey],@"contraction moves toward the target immediately with no queued animation");
    [v updateInteractiveTransitionToIndex:1 progress:0.5];
    Check(fabs(v.indicatorView.frame.size.width-origin.size.width*0.30)<0.001,@"mid-drag contracts to 30 percent of normal width");
    Check(fabs(CGRectGetMidX(v.indicatorView.frame)-140)<0.001,@"shortest indicator is directly under the target title");
    CGRect mid=v.indicatorView.frame; [v updateIndicatorPosition];
    Check(CGRectEqualToRect(mid,v.indicatorView.frame),@"ordinary layout keeps interactive progress");
    [v updateInteractiveTransitionToIndex:1 progress:0.1];
    Check(CGRectGetMidX(v.indicatorView.frame)<CGRectGetMidX(mid),@"reversing the finger reverses the indicator immediately");
    [v cancelInteractiveTransition];
    Check(!v.interactiveTransition && v.selectedIndex==0 && CGRectEqualToRect(v.indicatorView.frame,origin),@"cancel restores original group without committing a switch");
    v=Fixture(); [v updateInteractiveTransitionToIndex:1 progress:0.5];
    mid=v.indicatorView.frame; [v selectTabAtIndex:1 animated:YES];
    next=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey]; position=(id)next.animations[0];
    Check(!v.interactiveTransition && v.selectedIndex==1 && fabs([position.values[0] CGPointValue].x-CGRectGetMidX(mid))<0.001,@"commit settles from finger position without snapping back");
    CAKeyframeAnimation *settleSize=(id)next.animations[1];
    Check(settleSize.values.count==2 && fabs([settleSize.values.firstObject CGSizeValue].width-mid.size.width)<0.001 &&
        fabs([settleSize.values.lastObject CGSizeValue].width-origin.size.width)<0.001,@"release restores normal width without a second expansion peak");
    v=Fixture();
    BOOL bounded=YES;
    for (NSUInteger step=0;step<=20;step++) {
        [v updateInteractiveTransitionToIndex:1 progress:step/20.0];
        CGFloat ratio=v.indicatorView.frame.size.width/origin.size.width;
        bounded &= ratio>=0.30-0.001 && ratio<=1.001;
    }
    Check(bounded,@"entire drag stays between 30 and 100 percent of normal width");
    [v updateInteractiveTransitionToIndex:1 progress:0.5]; [v cancelInteractiveTransition];
    CAAnimationGroup *cancel=(id)[v.indicatorView.layer animationForKey:kIndicatorAnimationKey];
    Check([(CAKeyframeAnimation *)cancel.animations[1] values].count==2 && v.selectedIndex==0,@"cancel returns to the original group without extra stretch");
    v=Fixture(); [v updateInteractiveTransitionToIndex:1 progress:2];
    Check(fabs(CGRectGetMidX(v.indicatorView.frame)-140)<0.001 && fabs(v.indicatorView.frame.size.width-origin.size.width)<0.001,@"full drag clamps at target and contracts to final width");
    [testDefaults setBool:NO forKey:CSGroupIndicatorAnimationEnabledKey]; [v updateIndicatorPosition];
    Check(!v.interactiveTransition && CGRectEqualToRect(v.indicatorView.frame,origin),@"disabling animation during drag clears preview");
    [v updateInteractiveTransitionToIndex:1 progress:0.5];
    Check(!v.interactiveTransition && v.selectedIndex==0,@"disabled animation never previews a drag");
    [testDefaults setBool:YES forKey:CSGroupIndicatorAnimationEnabledKey]; reducedMotion=YES;
    [v updateInteractiveTransitionToIndex:1 progress:0.5];
    Check(!v.interactiveTransition,@"reduce motion also suppresses interactive stretch");
    reducedMotion=NO; [v updateInteractiveTransitionToIndex:99 progress:0.5];
    Check(!v.interactiveTransition,@"invalid adjacent target is ignored");
    TestSwipeGeometry();
    TestAnimationStyles();
    [testDefaults removePersistentDomainForName:suite];
    printf("Group indicator: %lu checks, %lu failures\n",(unsigned long)checks,(unsigned long)failures);
    return failures ? 1 : 0;
} }
