// Real readonly bridge + projection + adapter; no WeChat process or account.
static NSString *EntrySummary(CSGroupProjection *p) {
    return CSGroupReadObject([p rowAtDisplayPath:Path(0)],@"foldedEntrySummary");
}
static NativeSession *SummarySession(MainFrameCellDataManager *cache,NSString *name,unsigned int time,NSString *summary) {
    NativeSession *session=FoldedSession(name,0);session.m_uLastTime=time;
    session.m_msgWrap=[NativeMessage new];session.m_msgWrap.m_n64MesSvrID=0xF000000000000000ULL+time;
    NativeCellData *data=[NativeCellData new];data.m_sessionInfo=session;data.m_n64MesSvrID=session.m_msgWrap.m_n64MesSvrID;
    data.m_textForMessageLabel=summary;cache.cache[name]=data;return session;
}
static void RunFoldedSummaryTests(void) {
    NSString *oldAccount=account;CSCloseFriendSnapshot *oldPolicy=policy;id oldService=foldedService,oldCache=cellDataService;BOOL oldEnabled=groupEnabled;
    account=@"folded-summary-account";policy=Policy(@[@"hidden@chatroom"],NO,200);groupEnabled=YES;
    MainFrameCellDataManager *cache=[MainFrameCellDataManager new];cache.cache=[NSMutableDictionary dictionary];cellDataService=cache;
    ChatBoxMgr *manager=[ChatBoxMgr new];foldedService=manager;
    NativeSession *older=SummarySession(cache,@"z-old@chatroom",100,@"旧群: 小王: 早上好");
    NativeSession *newer=SummarySession(cache,@"a-new@chatroom",200,@"项目群: 小李: [图片]");
    NativeSession *hidden=SummarySession(cache,@"hidden@chatroom",500,@"密友秘密");
    NativeSession *outside=SummarySession(cache,@"outside@chatroom",900,@"其他分组秘密");
    NativeSession *private=SummarySession(cache,@"private",800,@"[链接] 原生标题");
    older.m_bIsTop=YES;manager.sourceSessions=@[outside,older,hidden,private,newer];
    WESessionTabItem *all=[WESessionTabItem tabWithType:WETabTypeAll],*tab=[WESessionTabItem tabWithType:WETabTypeCustom];
    tab.tabId=@"summary-custom";tab.sessionUserNames=@[older.m_nsUserName,newer.m_nsUserName,hidden.m_nsUserName];NSArray *tabs=@[all,tab];
    CSGroupListAdapter *adapter=[CSGroupListAdapter new];adapter.controller=[NativeHost new];adapter.preferences=[Preferences new];
    NSArray *native=@[@[Row(0,@"chatroom_session_box",CSGroupRowKindAggregate,CSGroupRowCategoryGroup,99)]];
    void (^publish)(void)=^{FoldedPublish(adapter,native,tabs,tab.tabId);};publish();
    Check(!strcmp([[newer.m_msgWrap methodSignatureForSelector:@selector(m_n64MesSvrID)] methodReturnType],@encode(long long)) &&
        [EntrySummary(adapter.projection) isEqual:@"项目群: 小李: [图片]"],@"real signed q message ID matches unsigned Q cache ID without losing high bits");
    Check([EntrySummary(adapter.projection) isEqual:@"项目群: 小李: [图片]"],@"newest visible folded native digest wins, excluding newer hidden and other-group children and ignoring pinned/list/lexical order");
    Check([CSGroupReadObject(adapter.projection.sections[0][0],@"foldedEntrySummaryUserName") isEqual:newer.m_nsUserName],@"summary carries the selected visible child identity in the immutable row");
    CSGroupProjection *unchanged=adapter.projection;publish();Check(adapter.projection==unchanged,@"unchanged verified summary reuses projection");
    NativeCellData *newData=cache.cache[newer.m_nsUserName];newData.m_textForMessageLabel=@"项目群: 小李: [引用] 原文";publish();
    Check(adapter.projection!=unchanged && [EntrySummary(adapter.projection) isEqual:newData.m_textForMessageLabel],@"native text-only update republishes even when count and unread stay equal");
    older.sortTimeOverride=300;publish();Check([EntrySummary(adapter.projection) isEqual:@"旧群: 小王: 早上好"],@"native sortTimeOverride participates in newest timestamp");
    older.sortTimeOverride=0;older.m_uTopTime=350;publish();Check([EntrySummary(adapter.projection) isEqual:@"旧群: 小王: 早上好"],@"native pinned effective timestamp participates without blindly preferring pinned rows");
    older.m_bIsTop=NO;older.m_uTopTime=0;older.m_uUnTopTime=400;publish();Check([EntrySummary(adapter.projection) isEqual:@"旧群: 小王: 早上好"],@"native untop time participates for non-pinned sessions");
    older.m_uUnTopTime=0;older.sortTime=450;publish();Check([EntrySummary(adapter.projection) isEqual:@"旧群: 小王: 早上好"],@"native sortTime participates for non-pinned sessions");older.sortTime=0;
    for(NSString *text in @[@"群名: 发言人: 消息",@"[图片]",@"[链接] https://example.invalid/a",@"[引用] 小明: 原文"]){
        newData.m_textForMessageLabel=text;publish();Check([EntrySummary(adapter.projection) isEqual:text],@"native prefixes and message-type digest text copied verbatim");
    }
    NSMutableString *mutable=[@"mutable native digest" mutableCopy];newData.m_textForMessageLabel=mutable;publish();NSString *captured=EntrySummary(adapter.projection);[mutable appendString:@" changed"];
    Check([captured isEqual:@"mutable native digest"],@"row snapshot owns immutable native text, never a live cell/model reference");
    newData.m_textForMessageLabel=[[NSAttributedString alloc] initWithString:@"原生富文本摘要"];publish();Check([EntrySummary(adapter.projection) isEqual:@"原生富文本摘要"],@"attributed native digest keeps visible text without native color overrides");
    newData.m_textForMessageLabel=nil;publish();Check(!EntrySummary(adapter.projection),@"missing latest native digest stays neutral instead of showing an older session as newest");
    // No native cell has ever been rendered: format the child's copied message,
    // not the global aggregate, live message, cache creator or older child.
    newer.m_msgWrap.fixtureDigest=@"[图片]";newer.m_contact=@"项目群成员: ";
    publish();Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: [图片]"],@"empty native message-label cache uses native formatting immediately on cold start");
    [cache.cache removeObjectForKey:newer.m_nsUserName];publish();
    Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: [图片]"],@"absent CellData uses native alternative before opening folded page");
    Check([CSGroupCopyFoldedRows().lastObject.nativeSummaryReason isEqual:@"ok_copy_cell_missing"],@"diagnostic distinguishes successful copy fallback after a cache miss");
    Check(lastFormattedMessage!=newer.m_msgWrap && newer.m_msgWrap.displayChanges==0 && cache.mutations==0 && digestCalls>0 && prefixCalls>0,
        @"native formatting and group prefix use a detached message; no host-message or cache mutation");
    for(NSString *digest in @[@"纯文本",@"[链接] 原生标题",@"[引用] 小明: 原文"]) {
        newer.m_msgWrap.fixtureDigest=digest;publish();Check([EntrySummary(adapter.projection) isEqual:[@"项目群成员: " stringByAppendingString:digest]],@"alternative retains native text, link and quote formatting on refresh");
    }
    newer.m_msgWrap.fixtureDigest=nil;publish();Check(!EntrySummary(adapter.projection),@"unavailable native formatter result stays neutral without borrowing another child");
    newer.m_msgWrap.fixtureDigest=@"刷新后可读";publish();Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: 刷新后可读"],@"subsequent list/message refresh retries a formerly missing digest");
    newData.m_textForMessageLabel=@"obsolete cached text";newData.m_n64MesSvrID++;cache.cache[newer.m_nsUserName]=newData;publish();
    Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: 刷新后可读"],@"mismatched cache cannot hide or replace a valid current message digest");
    [cache.cache removeObjectForKey:newer.m_nsUserName];newData.m_n64MesSvrID=newer.m_msgWrap.m_n64MesSvrID;
    newer.m_msgWrap.aliasCopy=YES;publish();Check(!EntrySummary(adapter.projection) && newer.m_msgWrap.displayChanges==0,@"copy returning the original cannot mutate the live message");newer.m_msgWrap.aliasCopy=NO;
    newer.m_msgWrap.m_n64MesSvrID=0;publish();Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: 刷新后可读"],@"local unsynced message can be formatted from its current stable snapshot without a server ID");
    newer.m_msgWrap.m_n64MesSvrID=0xF0000000000000C8ULL;
    onDigest=^{epoch++;};publish();Check(adapter.projection.sections.count==0,@"epoch change during native alternative drops all old content");onDigest=nil;
    onDigest=^{policy=Policy(@[newer.m_nsUserName],NO,203);};publish();Check(adapter.projection.sections.count==0,@"privacy revision change during native alternative cannot publish old digest");onDigest=nil;
    policy=Policy(@[@"hidden@chatroom"],NO,204);publish();Check([EntrySummary(adapter.projection) isEqual:@"项目群成员: 刷新后可读"],@"fresh valid snapshot recovers after policy transition");
    onDigest=^{account=@"other-alternative-account";};publish();Check(adapter.projection.sections.count==0,@"account switch during uncached native formatting cannot publish prior account text");onDigest=nil;account=@"folded-summary-account";
    tab.sessionUserNames=@[hidden.m_nsUserName];publish();Check(adapter.projection.sections[0].count==0,@"uncached formatter does not make an all-hidden group visible");
    tab.sessionUserNames=@[older.m_nsUserName,newer.m_nsUserName,hidden.m_nsUserName];
    newer.m_uLastTime=0;publish();Check(!EntrySummary(adapter.projection),@"unverifiable native sort timestamp stays neutral even when formatter succeeds");newer.m_uLastTime=200;
    onDigest=^{newer.m_msgWrap=[NativeMessage new];};publish();Check(!EntrySummary(adapter.projection),@"message replaced while formatting cannot publish the previous message digest");onDigest=nil;
    newer.m_msgWrap=[NativeMessage new];newer.m_msgWrap.m_n64MesSvrID=0xF0000000000000C8ULL;newer.m_contact=nil;
    cache.cache[newer.m_nsUserName]=newData;
    tab.sessionUserNames=@[private.m_nsUserName];private.m_msgWrap.fixtureDigest=@"[链接] 冷启动私聊";NativeCellData *privateData=cache.cache[private.m_nsUserName];[cache.cache removeObjectForKey:private.m_nsUserName];publish();
    Check([EntrySummary(adapter.projection) isEqual:@"[链接] 冷启动私聊"],@"private folded child formats without a group contact or prior page visit");
    cache.cache[private.m_nsUserName]=privateData;private.m_msgWrap.fixtureDigest=nil;tab.sessionUserNames=@[older.m_nsUserName,newer.m_nsUserName,hidden.m_nsUserName];
    newData.m_textForMessageLabel=@"valid latest";newData.m_n64MesSvrID++;publish();Check(!EntrySummary(adapter.projection),@"distinct unsigned 64-bit server IDs above LLONG_MAX cannot accidentally match through saturation");
    newData.m_n64MesSvrID=newer.m_msgWrap.m_n64MesSvrID;newData.m_sessionInfo=outside;publish();Check(!EntrySummary(adapter.projection),@"cache entry for a different session is rejected");
    newData.m_sessionInfo=newer;newer.m_msgWrap.m_n64MesSvrID=0;newData.m_n64MesSvrID=0;publish();Check(!EntrySummary(adapter.projection),@"unverifiable message identity stays neutral");
    newer.m_msgWrap.m_n64MesSvrID=0xF0000000000000C8ULL;newData.m_n64MesSvrID=newer.m_msgWrap.m_n64MesSvrID;
    [cache.cache removeObjectForKey:newer.m_nsUserName];publish();Check(!EntrySummary(adapter.projection),@"cache miss cannot borrow the global aggregate preview");cache.cache[newer.m_nsUserName]=newData;
    WrongCellDataGetter *wrong=[WrongCellDataGetter new];cellDataService=wrong;publish();Check(!EntrySummary(adapter.projection) && wrong.calls==0,@"unsupported scalar cache getter is rejected before invocation");cellDataService=cache;
    publish();Check(cache.reads>0 && cache.mutations==0 && outside.m_uUnReadCount==0 && manager.sourceSessions.count==5,@"snapshot uses only cache reads and leaves native sessions/unread unchanged");
    tab.sessionUserNames=@[private.m_nsUserName];publish();Check([EntrySummary(adapter.projection) isEqual:@"[链接] 原生标题"],@"private group summary uses its own native folded child");
    tab.sessionUserNames=@[hidden.m_nsUserName];publish();Check(adapter.projection.sections[0].count==0 && !EntrySummary(adapter.projection),@"all group members hidden removes entry and summary");
    tab.sessionUserNames=@[newer.m_nsUserName];cache.onRead=^{epoch++;};publish();Check(adapter.projection.sections.count==0,@"epoch change during summary read publishes no prior account content");cache.onRead=nil;
    cache.onRead=^{policy=Policy(@[newer.m_nsUserName],NO,201);};publish();Check(adapter.projection.sections.count==0,@"privacy revision change during summary read publishes no old policy content");cache.onRead=nil;publish();Check(adapter.projection.sections[0].count==0,@"next snapshot applies new privacy rules without stale digest");
    policy=Policy(@[],YES,202);cache.onRead=^{account=@"other-account";};publish();Check(adapter.projection.sections.count==0,@"account change during native summary lookup rejects publication");cache.onRead=nil;account=@"folded-summary-account";
    // A child snapshot with mismatched provenance may still provide count metadata,
    // but must never provide sensitive preview text to the parent.
    NSArray *rows=CSGroupCopyFoldedRows();
    for(NSNumber *kind in @[@0,@1,@2,@3]) {
        CSGroupProjection *child=[[CSGroupProjection alloc] initWithSections:@[rows] tabs:tabs selectedTabID:kind.intValue==1 ? all.tabId : tab.tabId filterDuplicates:kind.intValue==2 accountID:account hiddenUserNames:kind.intValue==3 ? [NSSet setWithObject:@"other"] : [NSSet set] privacyRevision:kind.intValue==0 ? 201 : 202 previousProjection:nil];
        CSGroupProjection *parent=[[CSGroupProjection alloc] initWithSections:native tabs:tabs selectedTabID:tab.tabId filterDuplicates:NO accountID:account hiddenUserNames:[NSSet set] unmaskedAggregateUserNames:[NSSet set] privacyRevision:202 scopeFoldedEntry:YES foldedProjection:child previousProjection:nil];
        Check(!EntrySummary(parent),@"mismatched child policy/group/filter provenance cannot publish a summary");
    }
    account=oldAccount;policy=oldPolicy;foldedService=oldService;cellDataService=oldCache;groupEnabled=oldEnabled;
}
