#import "CSListCornerPageContext.h"
FOUNDATION_EXPORT void CSListCornerSessionDecorate(UITableViewCell *cell, UITableView *table, NSIndexPath *path, id owner);
FOUNDATION_EXPORT CGRect CSListCornerSessionItemFrame(UIView *view, CGRect frame);
FOUNDATION_EXPORT CGFloat CSListCornerSessionRowHeight(id owner, UITableView *table, NSIndexPath *path, CGFloat nativeHeight);
