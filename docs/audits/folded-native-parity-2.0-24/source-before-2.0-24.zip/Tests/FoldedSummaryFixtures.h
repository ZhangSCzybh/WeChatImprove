// Optional initializer keeps these regressions executable against 2.0-21 (red).
@interface CSGroupRow (FoldedSummaryFixture)
- (instancetype)initWithNativePath:(NSIndexPath *)path userName:(NSString *)name
    kind:(CSGroupRowKind)kind category:(CSGroupRowCategory)category top:(BOOL)top
    unreadCount:(NSUInteger)unread redDot:(BOOL)dot nativeSummary:(NSString *)summary sortTime:(NSNumber *)time;
@end
static CSGroupRow *SummaryFixtureRow(NSIndexPath *path,NSString *name,NSString *summary,NSNumber *time) {
    if ([CSGroupRow instancesRespondToSelector:@selector(initWithNativePath:userName:kind:category:top:unreadCount:redDot:nativeSummary:sortTime:)])
        return [[CSGroupRow alloc] initWithNativePath:path userName:name kind:CSGroupRowKindSession category:CSGroupRowCategoryGroup
            top:NO unreadCount:0 redDot:NO nativeSummary:summary sortTime:time];
    return [[CSGroupRow alloc] initWithNativePath:path userName:name kind:CSGroupRowKindSession category:CSGroupRowCategoryGroup top:NO unreadCount:0 redDot:NO];
}
