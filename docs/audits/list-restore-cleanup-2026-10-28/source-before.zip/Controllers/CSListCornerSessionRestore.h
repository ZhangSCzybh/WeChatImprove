#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
// Only the verified NewMainFrameViewController.m_tableView is tracked.
FOUNDATION_EXPORT void CSListCornerTrackSessionTable(UITableView *table);
FOUNDATION_EXPORT void CSListCornerRestoreSessionTable(UITableView *table, NSString *stage);
FOUNDATION_EXPORT UIView *CSListCornerCreateSessionGap(UITableView *table, NSInteger section, BOOL footer, CGRect frame);
NS_ASSUME_NONNULL_END
