# 列表圆角完整重构（1.7-19）

本版以 `2aa7bcb8 / 1.7-17` 为功能基线，在独立分支 `codex/list-corners-refactor-1.7-17` 重构会话、通讯录、发现和我四页列表圆角。配置、页面适配和背景绘制各有明确归属；保留各页已有布局与配置语义。历史版本的文档与构建记录保留在 Git 历史和原审计目录中，本页描述本版实际实现。

## 模块归属

- `Hooks/ListCornerRadiusHooks.xm` 保留原生入口及回调链，将四页布局交给各自适配器；全部 35 个既有 Hook 方法保持对应。八个高度回调各执行一次原调用，然后按纯值策略计算。
- `CSListCornerConfiguration.h/.m` 集中原有 30 个持久化键、五项数值默认值及六套 RGBA。缓存不可变配置快照，每次装饰使用一个快照并按目标视图的 trait 选择深浅色；显式保存及 defaults 通知使缓存失效。通知处理仅失效，不写入 defaults。
- `CSListCornerSectionPolicy.h/.m` 仅依赖 Foundation 和输入值，不接触表格、视图或数据源。它保留会话置顶/普通间距、通讯录前四段合并及各页原有 header/footer 高度规则。
- `CSListCornerPageContext.h/.m` 识别控制器实际主表及有界 responder 归属，管理一次操作的背景、容器和重入边界。每次读取实际 contentView；不保存全局 Cell/table 强引用，不建立行数缓存。
- `CSListCornerSessionAdapter`、`ContactsAdapter`、`DiscoverAdapter`、`MoreAdapter` 分别维护四页专有布局。会话保留 MainFrame/Fake 宽度及横幅处理；通讯录按实际 section 数约束顶部四段查询；发现保留嵌套图文、富文本及角标，记录原始/已应用 frame 防止累计偏移；我页面独立处理列表与实际个人资料表头。
- `CSListCornerRenderer.h/.m` 继续提供 `CSListApplyCardBackground`。关联对象持有插件专属背景及遮罩，不接管碰巧使用相同 tag 的原生视图。只遮罩插件背景，背景不响应触摸；更换 contentView 时移除旧插件背景。

`SessionGroupHooks.xm` 和 `CSGroup*` 保持原样，继续唯一拥有分组投影、索引作用域、搜索表头、代理与手势。会话装饰通过原有 `CSGroupCardPosition` 查询显示首末行，启用分组但角色无效时退出，不猜测原生行数。不替换 delegate/dataSource/prefetch，不写主会话 tableHeaderView、contentInset 或 contentOffset，不请求分组刷新。

## 兼容行为

配置数值范围保持圆角 5–30、左右边距各 1–30、置顶及普通间距各 0–50。全零 RGBA 继续使用原有哨兵语义；保存和重启提示不变。恢复默认继续保留总开关及原重置流程未处理的距离背景色，设置项以身份而非显示标题识别。

装饰限制在实际所属列表及已识别的原生内容角色，使用当前容器的本地坐标，保留侧滑平移。尺寸无效时跳过装饰；原生重置 frame、颜色、mask 或路径后检查实际属性并修复。同样的尺寸、半径与首末角色复用遮罩和路径；位置及颜色变化只更新对应属性。没有离屏位图缓存或跳过整个 Cell 检查。

个人资料头部仅作用于“我”的实际主表表头，保留头像、昵称、微信号、二维码、状态按钮、展开高度及触摸区域。使用插件背景，不对原生业务容器加 mask；零高度状态容器的 hidden/alpha 由原生管理。以有界的正常布局失效替代直接调用 layoutSubviews 和全局 dispatch_once。

会话 viewDidAppear 在关闭圆角时仍保持 1.7-17 已有的背景及滚动条处理；关闭态 Cell/global layout 装饰不查询表格数据。发现页 viewWillAppear 原有异步单次 reload 暂时保留，尚无实机证据支持删除这项兼容刷新。未知私有容器保持原生布局，需重点实机检查新容器背景及分割线。

## 主机验证与安装包边界

实际生产逻辑验证：`bash Tests/verify-list-corners.sh`，756 项，0 失败。测试编译生产配置、策略、上下文、渲染器和四页适配器，提取当前八个高度回调及两个全局布局回调，使用实际分组角色函数和索引作用域。UIKit 为独立主机替身，配置存储为内存注入，不写用户真实 defaults。

覆盖配置键、颜色哨兵、缓存失效、保存/重置、285 个整数范围用例、原调用次数、高度期间禁止查询/reload、四种卡片角色、分组无效路径、非目标主表、复用和原生重置、容器替换、宽度变化、侧滑坐标、四页特殊布局、状态卡片展开与原生隐藏状态及重入边界。

受保护功能的 11 个分组主机回归命令共 647 项，0 失败；`bash Tests/verify-my-page-clean.sh` 另行通过（该命令不输出数字计数）。实际命令和输出见 [existing-feature-regressions.json](audits/list-corners-refactor-1.7-19/existing-feature-regressions.json)。审查发现的两项兼容问题已在 `de6e8273` 修复并复审，见 [review.md](audits/list-corners-refactor-1.7-19/review.md)。

1.7-19 验收包使用全新临时 Theos 输出目录构建完整 Release Rootless arm64 + arm64e 包；具体构建提交、命令、日志路径、包 SHA-256、control、安装位置、架构与符号检查以同目录 `build-validation.json` 为准。受保护源码与既有测试输入在打包前后按记录的哈希核对。原有包及工作区 `.theos` 不覆盖，不运行 clean/install。

主机断言和编译不能证明微信私有视图层级、真实 Hook 顺序、系统光栅化、目标设备启动或像素显示已通过。本版没有实机帧率、内存、耗电或性能提升的量化结论。用户安装后按 [ACCEPTANCE.md](audits/list-corners-refactor-1.7-19/ACCEPTANCE.md) 验证冷启动、四种圆角/分组开关组合、四页布局、搜索侧滑、隐藏/自定义入口、收藏验证、主题字号、宽度变化及状态卡片；所有实机项目当前均待验收。

## 1.7-20 实机反馈修复

用户提供 IMG_7396.PNG / IMG_7397.PNG 后，确认 1.7-19 对原生绘制层识别不足：通讯录标题外层背景不能覆盖 contentView/背景图片；Cell 自定义细线与稍后原生布局生成的分割线未被清理；资料头部独立的不透明底色盖住了插件圆角背景。

通讯录专用标题按背景、星标/文字、上下线分别处理，普通标题容器也保留文字并统一底色。MMTableSectionHeaderView 原生 layout 后仅在通讯录主表内修复，索引普通/拖动背景透明。Cell 细线检查限制到结构容器、最多四层、正高度不超过1点的宽边缘线；不扫描任意业务内容，不隐藏零高度状态内容和内部进度线。“我”页原生 Cell layout 后进行无行数查询的分割线修复；通讯录与我页面准备关闭原生额外表尾线。

资料头部只转移已识别的、不接收触摸的空背景容器底色，仍只裁剪插件背景，不对整个资料卡或状态容器加遮罩。原生底色复位后再次修复，头像、二维码、状态按钮继续由微信拥有。八个高度回调和聊天分组代码不变。

新增截图对应结构回归先得到769项/8失败，修复后及补充边界共775项/0失败；本轮另运行分组表头46、搜索36、交互124项（共206项/0失败）及 my-page-clean PASS。真实设备显示需用1.7-20再次验收。

## 1.7-21 发现页未读提示修复

移除把所有标签当标题、所有图片当左图标的重排方式，按原生标题/角标及右侧未读组合分别适配。整行包装保持原坐标系，长提示只收缩可确认的文字区，头像与红点尺寸、相对位置和纵坐标由原生保留。重复布局不累计偏移，原生宽度/内容变化重新计算；未知无法安全收缩的组合保留原生布局。保留 1.7-20 全部修复及八个高度回调。

本轮主机圆角回归 786 项/0 失败，分组表头/搜索/交互 206 项/0 失败，my-page-clean PASS。具体根因、原生静态依据、构建与设备验收边界见 [修复记录](audits/list-corners-fixes-1.7-21/README.md)。

## 1.7-22 通讯录底部统计区

好友数量属于 tableFooterView，独立于 section footer。补充原生 initCountLabel: 和页面布局之后的背景修复，只识别实际通讯录主表及当前 footer 内的 m_countLabel，保留人数、样式与高度。原生创建、页面返回及布局后与通讯录 canvas 底色一致；没有行数查询、列表刷新或 footer 替换。主机回归 797 项/0 失败。详情见 [1.7-22 修复记录](audits/list-corners-fixes-1.7-22/README.md)。

## 1.7-23 无行为变更清理

删除 footer 纯值函数的三个未使用参数，收回两个文件内部函数和四个上下文属性的公共声明，合并重复 object ivar 读取并保持短路访问顺序，删除设置颜色预览的多余 setNeedsDisplay。未发现生产调试日志/探针；四页适配与渲染器、测试用例和基线保持 1.7-22 原样。

当前验证：圆角 797 项、分组 647 项均零失败，my-page-clean PASS。与 1.7-17 的逐项收益及性能限制见 [清理与对比记录](audits/list-corners-cleanup-1.7-23/README.md)。路径缓存原本已存在，不列为新增优化；未进行真机帧率、内存、启动耗时或耗电对比。

## 1.7-24 首次进入会话列表尺寸修复

真实/占位会话 Cell 原生 layout 完成后，按当前真实内容尺寸校正已存在的卡片背景与遮罩，沿用渲染器中的首末角状态。修复显示回调早于最终行高确定时背景覆盖不足的问题；内容容器替换时转移已有背景。此路径无行数/路径查询、分组投影重算、列表刷新或异步补偿。八个高度回调不变。主机圆角868项、分组相关278项全部通过；实机首次启动显示待验收。见 [本轮记录](audits/list-corners-first-layout-1.7-24/README.md)。


## 2.1-3 前台画布恢复

2.1-2-muted-background 的实际构建输入为本轮基线。会话卡片内部的底色与左右画布由 cell 装饰绘制；section 间隔默认透明，依赖 table / backgroundView 的画布。返回前台不保证控制器重新出现或布局，旧链路没有激活通知与 table 自身布局后的补齐，可能留下“卡片正确、间隔和底部画布错误”的状态。

新增 CSListCornerSessionRestore 仅跟踪真实 NewMainFrameViewController.m_tableView：前台/激活通知同步补齐已有外观、setNeedsDisplay 使旧帧失效，并 setNeedsLayout 交给 UIKit 正常提交；MainFrameTableView 原生布局和背景 setter 返回后再次校正，处理后续原生覆盖。注册按 table 生命周期持有、弱引用 table 和本插件创建的 gap；不处理其他列表。尺寸未就绪保留已有卡片，等待原生有效布局，不轮询。颜色、间距、section 角色及折叠行连续卡片规则沿用已有实现，不查询或 reload 数据，不设置 contentOffset/contentInset。

仅运行 verify-list-corners.sh：失败复现 1,349 项 / 167 失败，补充显示失效用例后最终 1,357 项 / 0 失败。覆盖恢复首帧、未读与 section 变化、两轮前后台、scene、延后原生布局/背景替换、空组、零尺寸、重入及关闭再开。host 替身不能代替五条真机触发路径的概率/未读相关性测量。诊断开关、原生地址、构建与验收记录见 [本轮报告](audits/list-restore-2.1-3/README.md)。
