#import <Foundation/Foundation.h>
#import "CSPaymentAutomation.h"
#import "CSPaymentLedger.h"
#import <objc/message.h>
static NSUserDefaults *paymentDefaults;
static NSUInteger checks, originalCallbacks, nativeStarts, sentMessages, submittedTransfers, submittedQueries, submittedOpens;
static NSMutableArray *requests;
static NSString *testAccount=@"self";
static BOOL nativePaymentBusy;
#define CHECK(c) do { checks++; if (!(c)) { fprintf(stderr,"FAIL %d: %s\n",__LINE__,#c); exit(1); } } while(0)
NSString *const UIApplicationDidBecomeActiveNotification=@"TestActive", *const UIApplicationDidEnterBackgroundNotification=@"TestBackground";
id CSGetService(Class cls) { static NSMutableDictionary *services; if (!services) services=[NSMutableDictionary dictionary]; NSString *key=NSStringFromClass(cls); if (!key) return nil; if (!services[key]) services[key]=[cls new]; return services[key]; }
#import "PaymentAutomationUnderTest.h"
@interface TestContact : NSObject
@property NSString *m_nsUsrName;
@end
@implementation TestContact @end
@interface CContactMgr : NSObject
- (id)getSelfContact;
@end
@implementation CContactMgr
- (id)getSelfContact { TestContact *c=[TestContact new]; c.m_nsUsrName=testAccount; return c; }
@end
@interface TestBuffer : NSObject
@property NSData *buffer;
@end
@implementation TestBuffer @end
static id Buffer(NSDictionary *data) { TestBuffer *b=[TestBuffer new]; b.buffer=[NSJSONSerialization dataWithJSONObject:data options:0 error:NULL]; return b; }
@interface TestBase : NSObject
@property NSInteger ret;
@end
@implementation TestBase @end
@interface TestResponse : NSObject
@property TestBase *baseResponse;
@property NSInteger cgiCmdid, errorType, tenpayErrType, platRet;
@property TestBuffer *retText;
@end
@implementation TestResponse @end
@interface TestRequest : NSObject
@property TestBuffer *reqText;
@property NSInteger cgiCmd;
@end
@implementation TestRequest @end
@interface TenPayRequest : TestRequest @end
@implementation TenPayRequest
- (void)setReqText:(id)buffer { [super setReqText:buffer]; CSPaymentCaptureRequest(self,buffer,NO); }
@end
@interface HongBaoReq : TestRequest @end
@implementation HongBaoReq
- (void)setReqText:(id)buffer { [super setReqText:buffer]; CSPaymentCaptureRequest(self,buffer,YES); }
@end
@interface WCPayControlData : NSObject
@property NSString *m_nsTransferID, *selectedTransferChatroomUsername;
@property NSNumber *m_uiTransferInvalidTime;
@end
@implementation WCPayControlData @end
@interface WCPayReveiverControlTransferControlLogic : NSObject
@property WCPayControlData *data;
- (id)initWithData:(id)data;
- (void)startLogic;
- (void)nativeConfirm;
- (void)OnWCPayTransferMoneyStatusViewControllerConfirmTransfer;
@end
@implementation WCPayReveiverControlTransferControlLogic
#import "PaymentLogicHooksUnderTest.h"
- (void)nativeConfirm {
    NSMutableDictionary *p=[@{@"trans_id":self.data.m_nsTransferID,@"op":@"confirm"} mutableCopy];
    if (self.data.selectedTransferChatroomUsername) p[@"group_username"]=self.data.selectedTransferChatroomUsername;
    TenPayRequest *r=[TenPayRequest new]; r.cgiCmd=42; r.reqText=Buffer(p); [requests addObject:r]; submittedTransfers++;
}

@end
@interface WCPayControlMgr : NSObject
@property NSMutableArray *logics;
- (unsigned int)startReceiverConfirmTransferMoneyLogic:(id)vc Data:(id)data;
@end
@implementation WCPayControlMgr
- (BOOL)IsDoingWCPayLogic:(Class)c { return nativePaymentBusy; }
- (unsigned int)startReceiverConfirmTransferMoneyLogic:(id)vc Data:(id)data { WCPayReveiverControlTransferControlLogic *l=[[WCPayReveiverControlTransferControlLogic alloc] initWithData:data]; if (!self.logics) self.logics=[NSMutableArray array]; [self.logics addObject:l]; [l startLogic]; return 1; }
@end
@interface WCPayLogicMgr : NSObject
- (void)nativeLicense:(dispatch_block_t)block;
@end
@implementation WCPayLogicMgr
- (void)nativeLicense:(dispatch_block_t)block { if (block) block(); }
#import "PaymentResponseHooksUnderTest.h"
@end
@interface WCRedEnvelopesLogicMgr : NSObject
- (void)ReceiverQueryRedEnvelopesRequest:(id)params;
- (void)OpenRedEnvelopesRequest:(id)params;
@end
@implementation WCRedEnvelopesLogicMgr
- (void)ReceiverQueryRedEnvelopesRequest:(id)p { HongBaoReq *r=[HongBaoReq new]; r.cgiCmd=3; r.reqText=Buffer(p); [requests addObject:r]; submittedQueries++; }
- (void)OpenRedEnvelopesRequest:(id)p { HongBaoReq *r=[HongBaoReq new]; r.cgiCmd=4; r.reqText=Buffer(p); [requests addObject:r]; submittedOpens++; }
#import "EnvelopeResponseHooksUnderTest.h"
@end
@interface TestPayInfo : NSObject
@property NSString *m_nsTransferID, *transfer_receiver_username, *transfer_payer_username, *m_c2cNativeUrl;
@property NSUInteger m_uiPaySubType;
@end
@implementation TestPayInfo @end
@interface CMessageWrap : NSObject
@property unsigned int m_uiMessageType, m_uiCreateTime, m_uiStatus;
@property NSString *m_nsContent, *m_nsFromUsr, *m_nsToUsr, *m_nsRealChatUsr;
@property TestPayInfo *m_oWCPayInfoItem;
- (id)initWithMsgType:(unsigned int)type;
@end
@implementation CMessageWrap
- (id)initWithMsgType:(unsigned int)type { if ((self=[super init])) _m_uiMessageType=type; return self; }
@end
@interface CMessageMgr : NSObject
- (void)AddMsg:(id)session MsgWrap:(id)wrap;
@end
@implementation CMessageMgr
- (void)AddMsg:(id)session MsgWrap:(id)wrap { sentMessages++; }
@end
static void Drain(void) { for (NSInteger i=0;i<8;i++) [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.005]]; }
static void Until(BOOL (^done)(void)) { NSDate *end=[NSDate dateWithTimeIntervalSinceNow:4]; while (!done() && end.timeIntervalSinceNow>0) Drain(); CHECK(done()); }
static void Setup(void) {
    for (CSPaymentTask *t in store.tasks) CSFinish(t,YES);
    store=[CSPaymentTaskStore new]; requests=[NSMutableArray array]; submittedTransfers=submittedQueries=submittedOpens=sentMessages=0;
    testAccount=@"self"; nativePaymentBusy=NO;
    [paymentDefaults setBool:YES forKey:@"kReceiveTransferAutoEnableKey"];
    [paymentDefaults setBool:YES forKey:@"kReceiveTransferPrivateEnableKey"];
    [paymentDefaults setBool:YES forKey:@"kReceiveTransferGroupEnableKey"];
    [paymentDefaults setBool:YES forKey:@"kReceiveTransferAutoReplyEnableKey"];
    [paymentDefaults setObject:@"thanks" forKey:@"kReceiveTransferPrivateAutoReplyKey"];
    [paymentDefaults setObject:@"thanks" forKey:@"kReceiveTransferGroupAutoReplyKey"];
    [paymentDefaults setInteger:0 forKey:@"kReceiveTransferDelayKey"];
    [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.autoReceive"];
    [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.privateEnable"];
    [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.groupEnable"];
    [paymentDefaults setBool:NO forKey:@"com.wechat.enhance.redenvelop.serialReceive"];
    [paymentDefaults setInteger:0 forKey:@"com.wechat.enhance.redenvelop.delay"];
    [paymentDefaults setObject:@"thanks" forKey:@"com.wechat.enhance.redenvelop.groupReply"];
    transferSettings=CSSettings(NO); envelopeSettings=CSSettings(YES);
    atomic_store(&transferEnabled,true); atomic_store(&envelopeEnabled,true); activeAccount=CSAccount();
}
static CMessageWrap *Message(NSString *identifier, NSString *receiver, BOOL env) {
    CMessageWrap *w=[[CMessageWrap alloc] initWithMsgType:49]; w.m_nsFromUsr=@"room@chatroom"; w.m_nsToUsr=@"self";
    TestPayInfo *p=[TestPayInfo new]; p.m_nsTransferID=identifier; p.transfer_receiver_username=receiver; p.transfer_payer_username=@"payer"; p.m_uiPaySubType=1;
    p.m_c2cNativeUrl=[NSString stringWithFormat:@"wxpay://c2cbizmessagehandler/hongbao/receivehongbao?sendid=%@&channelid=1&msgtype=1&sign=s",identifier]; w.m_oWCPayInfoItem=p;
    w.m_nsContent=[NSString stringWithFormat:@"<msg><wcpayinfo><transferid>%@</transferid><paysubtype>1</paysubtype></wcpayinfo></msg>",identifier]; return w;
}
static TestResponse *Response(id request, NSDictionary *body) { TestResponse *r=[TestResponse new]; r.baseResponse=[TestBase new]; r.cgiCmdid=[request cgiCmd]; r.retText=Buffer(body); return r; }
static void Respond(id req, NSDictionary *body, BOOL env) {
    id mgr=CSGetService(NSClassFromString(env?@"WCRedEnvelopesLogicMgr":@"WCPayLogicMgr"));
    SEL s=NSSelectorFromString(env?@"OnWCToHongbaoCommonResponse:Request:":@"OnWCToTenpayCommonResponse:Request:");
    ((void(*)(id,SEL,id,id))objc_msgSend)(mgr,s,Response(req,body),req); Drain();
}
int main(void) { @autoreleasepool {
    NSString *suite=[@"payment-automation-tests-" stringByAppendingString:NSUUID.UUID.UUIDString]; paymentDefaults=[[NSUserDefaults alloc] initWithSuiteName:suite];
    NSURL *dir=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:suite]];
    ledger=[[CSPaymentLedger alloc] initWithURL:[dir URLByAppendingPathComponent:@"ledger.plist"] defaults:paymentDefaults];
    __block BOOL loaded=NO; [ledger load:^{loaded=YES;}]; Until(^BOOL{ return loaded; }); CHECK(ledger.ready);
    Setup();
    CMessageWrap *third=Message(@"third",@"other",NO); CSPaymentAdmitMessage(third,NO); Drain(); CHECK(!submittedTransfers && !sentMessages && !store.tasks.count);
    third.m_oWCPayInfoItem.m_uiPaySubType=3; CSPaymentAdmitMessage(third,NO); Drain(); CHECK(!submittedTransfers);
    WCPayReveiverControlTransferControlLogic *manual=[[WCPayReveiverControlTransferControlLogic alloc] initWithData:[WCPayControlData new]];
    [manual startLogic]; CHECK(nativeStarts==1);
    nativePaymentBusy=YES; CSPaymentAdmitMessage(Message(@"manual-busy",@"self",NO),NO); Drain(); CHECK(!submittedTransfers); nativePaymentBusy=NO;
    CMessageWrap *mine=Message(@"mine",@"self",NO); CSPaymentAdmitMessage(mine,NO); CSPaymentAdmitMessage(mine,NO); Drain();
    CHECK(submittedTransfers==1); CHECK(sentMessages==0); CHECK(CSPaymentOwner(requests.lastObject)!=nil);
    NSDictionary *success=@{@"retcode":@0,@"fee":@4250,@"fee_type":@"CNY",@"payer":@"payer",@"receiver":@"self"};
    id request=requests.lastObject; Respond(request,success,NO); Until(^BOOL{ return sentMessages==1; });
    Respond(request,success,NO); CHECK(sentMessages==1); CHECK([paymentDefaults integerForKey:@"kReceiveTransferTotalCountKey"]==1); CHECK(!store.tasks.count);
    TenPayRequest *unowned=[TenPayRequest new]; unowned.cgiCmd=42; unowned.reqText=Buffer(@{@"trans_id":@"manual",@"op":@"confirm"}); Respond(unowned,success,NO); CHECK(sentMessages==1);
    Setup(); CSPaymentAdmitMessage(Message(@"error",@"self",NO),NO); Drain();
    Respond(requests.lastObject,@{@"retcode":@1,@"fee":@4250,@"fee_type":@"CNY",@"payer":@"payer",@"receiver":@"self"},NO); CHECK(!sentMessages && !store.tasks.count);
    Setup(); [paymentDefaults setInteger:10 forKey:@"kReceiveTransferDelayKey"]; transferSettings=CSSettings(NO); CSPaymentAdmitMessage(Message(@"disabled",@"self",NO),NO); Drain(); CHECK(store.tasks.count==1 && !submittedTransfers);
    [paymentDefaults setBool:NO forKey:@"kReceiveTransferAutoEnableKey"]; CSPaymentReload(); Drain(); CHECK(!store.tasks.count && !submittedTransfers);
    Setup(); CSPaymentAdmitMessage(Message(@"epoch",@"self",NO),NO); Drain(); request=requests.lastObject;
    CSPaymentAccountWillChange(); testAccount=@"new-self"; CSPaymentAccountDidChange(); Respond(request,success,NO); CHECK(!sentMessages && !store.tasks.count);
    Setup(); CSPaymentAdmitMessage(Message(@"relogin",@"self",NO),NO); Drain(); request=requests.lastObject;
    CSPaymentAccountWillChange(); CSPaymentAccountDidChange(); Respond(request,success,NO); CHECK(!sentMessages);
    Setup(); CSPaymentAdmitMessage(Message(@"success-after-disable",@"self",NO),NO); Drain(); request=requests.lastObject;
    NSInteger countBefore=[paymentDefaults integerForKey:@"kReceiveTransferTotalCountKey"];
    [paymentDefaults setBool:NO forKey:@"kReceiveTransferAutoEnableKey"]; CSPaymentReload(); Drain(); CHECK(store.tasks.count==1);
    Respond(request,success,NO); Until(^BOOL{ return [paymentDefaults integerForKey:@"kReceiveTransferTotalCountKey"]==countBefore+1; }); CHECK(!sentMessages);
    Setup(); CSPaymentTask *deferred=[CSPaymentTask new]; deferred.account=@"self"; deferred.epoch=atomic_load(&paymentEpoch); deferred.key=@"deferred"; deferred.session=@"room@chatroom"; deferred.phase=CSPaymentConfirming; deferred.deadline=CSNow()+30;
    CHECK([store add:deferred now:CSNow()]);
    __block dispatch_block_t accept=nil; __block NSUInteger accepted=0;
    CSPaymentWithOwner(deferred,^{ accept=CSPaymentGuardConfirmation(^{ accepted++; }); });
    accept(); CHECK(accepted==1);
    CSPaymentAccountWillChange(); CSPaymentAccountDidChange(); accept(); CHECK(accepted==1); Drain();
    Setup(); CSPaymentAdmitMessage(Message(@"timeout",@"self",NO),NO); Drain(); request=requests.lastObject; store.tasks.firstObject.deadline=CSNow()-10000; CSPump(); Respond(request,success,NO); CHECK(!sentMessages && !store.tasks.count);

    Setup(); [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.serialReceive"]; envelopeSettings=CSSettings(YES);
    for (NSInteger i=0;i<3;i++) CSPaymentAdmitMessage(Message([NSString stringWithFormat:@"env%ld",(long)i],@"self",YES),YES);
    Drain(); CHECK(submittedQueries==1 && submittedOpens==0);
    request=requests.lastObject; NSDictionary *query=@{@"retcode":@0,@"receiveStatus":@0,@"hbStatus":@2,@"timingIdentifier":@"token"};
    Respond(request,query,YES); CHECK(submittedOpens==1 && submittedQueries==1); CHECK(store.tasks.count==3);
    id open=requests.lastObject; Respond(request,query,YES); CHECK(submittedOpens==1);
    Respond(open,@{@"retcode":@0,@"amount":@100},YES); Until(^BOOL{ return sentMessages==1; }); CHECK(submittedQueries==2); CHECK(store.tasks.count==2);
    Respond(open,@{@"retcode":@0,@"amount":@100},YES); CHECK(sentMessages==1);
    Respond(requests.lastObject,@{@"retcode":@0,@"receiveStatus":@2,@"hbStatus":@2},YES); CHECK(store.tasks.count==1);
    Respond(requests.lastObject,@{@"retcode":@0,@"receiveStatus":NSNull.null,@"hbStatus":@2},YES); CHECK(!store.tasks.count);
    Setup(); for (NSInteger i=0;i<8;i++) CSPaymentAdmitMessage(Message([NSString stringWithFormat:@"parallel%ld",(long)i],@"self",YES),YES);
    Drain(); CHECK(submittedQueries==5 && store.tasks.count==8);
    [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.serialReceive"]; CSPaymentReload(); Drain(); CHECK(submittedQueries==5);
    NSArray *active=[requests copy]; for (id r in active) Respond(r,@{@"retcode":@1},YES);
    CHECK(submittedQueries==6); CHECK(store.tasks.count==3);
    [paymentDefaults setBool:NO forKey:@"com.wechat.enhance.redenvelop.autoReceive"]; CSPaymentReload(); Drain(); CHECK(!store.tasks.count);
    NSUInteger replies=sentMessages; Respond(requests.lastObject,@{@"retcode":@0,@"amount":@100},YES); CHECK(sentMessages==replies);
    Setup(); CMessageWrap *outgoing=Message(@"outgoing",@"self",YES); outgoing.m_nsFromUsr=@"self"; outgoing.m_nsToUsr=@"friend"; CSPaymentAdmitMessage(outgoing,YES); Drain(); CHECK(!submittedQueries);
    CMessageWrap *groupSelf=Message(@"group-self",@"self",YES); groupSelf.m_nsRealChatUsr=@"self"; CSPaymentAdmitMessage(groupSelf,YES); Drain(); CHECK(!submittedQueries);
    CMessageWrap *missing=Message(@"missing",@"self",YES); missing.m_oWCPayInfoItem.m_c2cNativeUrl=@"wxpay://c2cbizmessagehandler/hongbao/receivehongbao?sendid=missing"; CSPaymentAdmitMessage(missing,YES); Drain(); CHECK(!submittedQueries);
    Setup(); CSPaymentAdmitMessage(Message(@"mismatch",@"self",YES),YES); Drain(); HongBaoReq *r=requests.lastObject;
    r.reqText=Buffer(@{@"sendId":@"other",@"channelId":@"1",@"msgType":@"1",@"nativeUrl":@"other"}); Respond(r,query,YES); CHECK(!store.tasks.count && !submittedOpens);
    Setup(); CMessageWrap *privateMessage=Message(@"private-success",@"self",NO); privateMessage.m_nsFromUsr=@"payer"; CSPaymentAdmitMessage(privateMessage,NO); Drain();
    CHECK(submittedTransfers==1); Respond(requests.lastObject,success,NO); Until(^BOOL{ return sentMessages==1; });
    Setup(); CSPaymentAdmitMessage(Message(@"transport",@"self",YES),YES); Drain();
    TestResponse *transport=Response(requests.lastObject,query); transport.platRet=1;
    [(id)CSGetService(WCRedEnvelopesLogicMgr.class) OnWCToHongbaoCommonResponse:transport Request:requests.lastObject]; Drain(); CHECK(!store.tasks.count && !submittedOpens);
    Setup(); CSPaymentAdmitMessage(Message(@"bad-timing",@"self",YES),YES); Drain();
    Respond(requests.lastObject,@{@"retcode":@0,@"receiveStatus":@0,@"hbStatus":@2,@"timingIdentifier":NSNull.null},YES); CHECK(!store.tasks.count && !submittedOpens);
    Setup(); CSPaymentAdmitMessage(Message(@"bad-amount",@"self",YES),YES); Drain(); Respond(requests.lastObject,query,YES); CHECK(submittedOpens==1);
    Respond(requests.lastObject,@{@"retcode":@0,@"amount":NSNull.null},YES); CHECK(!store.tasks.count && !sentMessages);
    Setup(); [paymentDefaults setInteger:10 forKey:@"com.wechat.enhance.redenvelop.delay"]; [paymentDefaults setBool:YES forKey:@"com.wechat.enhance.redenvelop.serialReceive"]; envelopeSettings=CSSettings(YES);
    CSPaymentAdmitMessage(Message(@"delayed-envelope",@"self",YES),YES); Drain(); Respond(requests.lastObject,query,YES); CHECK(!submittedOpens && store.tasks.firstObject.phase==CSPaymentReady);
    store.tasks.firstObject.deadline=CSNow()-100; CSPump(); CHECK(!submittedOpens && !store.tasks.count);
    Setup(); [paymentDefaults setInteger:1 forKey:@"com.wechat.enhance.redenvelop.groupScope"]; [paymentDefaults setObject:@[@"other@chatroom"] forKey:@"com.wechat.enhance.redenvelop.allowedGroups"]; envelopeSettings=CSSettings(YES);
    CSPaymentAdmitMessage(Message(@"whitelist",@"self",YES),YES); Drain(); CHECK(!submittedQueries);
    [paymentDefaults setInteger:0 forKey:@"com.wechat.enhance.redenvelop.groupScope"];
    [paymentDefaults setInteger:-100 forKey:@"kReceiveTransferDelayKey"]; CHECK([CSSettings(NO)[@"delay"] integerValue]==0);
    [paymentDefaults setInteger:100000 forKey:@"com.wechat.enhance.redenvelop.delay"]; CHECK([CSSettings(YES)[@"delay"] integerValue]==10);
    Setup(); for (NSInteger i=0;i<1000;i++) { CMessageWrap *w=[CMessageWrap new]; w.m_uiMessageType=1; CSPaymentAdmitMessage(w,YES); CSPaymentAdmitMessage(w,NO); } Drain(); CHECK(!store.tasks.count && !submittedQueries && !submittedTransfers && !timer);
    CHECK(originalCallbacks>=15);
    if (timer) { dispatch_source_cancel(timer); timer=nil; }
    [paymentDefaults removePersistentDomainForName:suite]; [NSFileManager.defaultManager removeItemAtURL:dir error:NULL];
    printf("Payment automation: %lu checks passed; native callbacks preserved\n",(unsigned long)checks);
} return 0; }
