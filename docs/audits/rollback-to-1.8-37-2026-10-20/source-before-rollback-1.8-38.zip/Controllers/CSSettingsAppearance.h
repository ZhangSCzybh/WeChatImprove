#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
/// Presentation helpers scoped to backup and restore preview pages.
void CSSettingsPrepareTable(UITableView *tableView);
UITableViewCell *CSSettingsRow(UITableView *tableView, NSString *title,
                              NSString * _Nullable detail, NSString * _Nullable symbol,
                              UIColor * _Nullable tint, BOOL disclosure);
UITableViewCell *CSSettingsSummary(UITableView *tableView, NSString *title,
                                  NSString *detail, NSString *symbol, UIColor *tint);
NSString *CSSettingsBackupDate(NSDate * _Nullable date);
NS_ASSUME_NONNULL_END
