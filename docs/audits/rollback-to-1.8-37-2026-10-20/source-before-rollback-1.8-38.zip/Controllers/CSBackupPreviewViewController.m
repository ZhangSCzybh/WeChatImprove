#import "CSBackupPreviewViewController.h"
#import "CSBackupManager.h"
#import "CSBackupRegistry.h"
#import "CSSettingsAppearance.h"
@interface CSBackupPreviewViewController ()
@property(nonatomic) NSDictionary *snapshot;
@property(nonatomic) NSDictionary *preview;
@property(nonatomic) NSArray *modules;
@property(nonatomic) NSArray *accounts;
@property(nonatomic) NSMutableSet *selectedModules;
@property(nonatomic) NSMutableSet *selectedAccounts;
@property(nonatomic) NSString *message;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) BOOL busy;
@end
@implementation CSBackupPreviewViewController
- (instancetype)initWithSnapshot:(NSDictionary *)snapshot {if((self=[super initWithStyle:UITableViewStyleInsetGrouped]))_snapshot=snapshot;return self;}
- (void)viewDidLoad {
    [super viewDidLoad];self.title=@"预览恢复";self.message=@"正在校验备份和当前配置…";CSSettingsPrepareTable(self.tableView);
    NSMutableSet *modules=[NSMutableSet set],*accounts=[NSMutableSet set];
    for(NSDictionary *f in self.snapshot[@"fields"]){NSDictionary *entry=[CSBackupRegistry entryForDomain:f[@"domain"] key:f[@"key"]];[modules addObject:entry[@"module"]];if([f[@"key"] isEqual:@"com.wechat.enhance.chat_group.account_profiles"]&&[f[@"value"] isKindOfClass:NSDictionary.class])[accounts addObjectsFromArray:[f[@"value"] allKeys]];}
    if([self.snapshot[@"source"][@"accounts"] isKindOfClass:NSArray.class])[accounts addObjectsFromArray:self.snapshot[@"source"][@"accounts"]];
    NSString *current=[CSBackupManager.sharedManager currentContext][@"account"];
    if(current.length)[accounts addObject:current];self.modules=[modules.allObjects sortedArrayUsingSelector:@selector(compare:)];self.accounts=[accounts.allObjects sortedArrayUsingSelector:@selector(compare:)];
    self.selectedModules=[modules mutableCopy];self.selectedAccounts=[NSMutableSet set];if(current.length)[self.selectedAccounts addObject:current];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"准备恢复" style:UIBarButtonItemStyleDone target:self action:@selector(confirm)];[self refreshPreview];
}
- (void)refreshPreview {
    NSUInteger generation=++self.generation;self.busy=YES;self.navigationItem.rightBarButtonItem.enabled=NO;
    [CSBackupManager.sharedManager preview:self.snapshot modules:self.selectedModules.copy accounts:self.selectedAccounts.copy completion:^(NSDictionary *preview,NSError *error){
        if(generation!=self.generation)return;self.busy=NO;self.preview=preview;self.message=error.localizedDescription;self.navigationItem.rightBarButtonItem.enabled=preview!=nil;[self.tableView reloadData];
    }];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 4; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 1 + [self.preview[@"warnings"] count];
    if (section == 1) return self.modules.count;
    if (section == 2) return MAX(1, self.accounts.count);
    return MAX(1, [self.preview[@"changes"] count]);
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 1) return [NSString stringWithFormat:@"恢复模块 · 已选 %lu / %lu", (unsigned long)self.selectedModules.count, (unsigned long)self.modules.count];
    if (section == 2) return @"账号分组范围";
    if (section == 3) return [NSString stringWithFormat:@"变更明细 · %lu 项", (unsigned long)[self.preview[@"changes"] count]];
    return nil;
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 1) return @"点击勾选要恢复的模块，未选模块保留当前设置。";
    if (section == 2) return @"默认选择当前账号。其他账号的分组写回原账号；联系人和群关系仅支持同一本机、同一当前账号。";
    if (section == 3) return @"准备恢复前会保存保护备份。手动退出并重新打开微信后应用。";
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    if (path.section == 0) {
        if (path.row > 0) return CSSettingsRow(tableView, @"恢复提示", self.preview[@"warnings"][path.row - 1], @"exclamationmark.circle", UIColor.systemOrangeColor, NO);
        NSString *detail = self.busy ? @"正在校验备份和当前配置…" : self.message;
        if (!detail) detail = [NSString stringWithFormat:@"%@ · 版本 %@\n%lu 项将变化 · %lu 张图片", CSSettingsBackupDate(self.snapshot[@"createdAt"]), self.snapshot[@"source"][@"pluginVersion"] ?: @"未知", (unsigned long)[self.preview[@"changes"] count], (unsigned long)[self.snapshot[@"assets"] count]];
        return CSSettingsSummary(tableView, self.snapshot[@"name"] ?: @"恢复概览", detail, self.message && !self.busy ? @"exclamationmark.circle" : @"arrow.counterclockwise.circle", self.message && !self.busy ? UIColor.systemOrangeColor : UIColor.systemGreenColor);
    }
    if (path.section == 1 || path.section == 2) {
        BOOL accountRow = path.section == 2;
        if (accountRow && !self.accounts.count) return CSSettingsRow(tableView, @"暂无账号分组", @"当前备份未记录可选择的账号", @"person.crop.circle", UIColor.secondaryLabelColor, NO);
        NSString *value = (accountRow ? self.accounts : self.modules)[path.row];
        BOOL selected = [(accountRow ? self.selectedAccounts : self.selectedModules) containsObject:value];
        NSString *title = accountRow ? value : ([CSBackupRegistry moduleTitles][value] ?: value);
        NSString *detail = accountRow ? ([value isEqual:[CSBackupManager.sharedManager currentContext][@"account"]] ? @"当前账号" : @"其他已存档账号") : nil;
        UITableViewCell *cell = CSSettingsRow(tableView, title, detail, selected ? @"checkmark.circle.fill" : @"circle", selected ? UIColor.systemGreenColor : UIColor.tertiaryLabelColor, NO);
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
        cell.accessibilityTraits = UIAccessibilityTraitButton | (selected ? UIAccessibilityTraitSelected : 0);
        cell.accessibilityValue = selected ? @"已选择" : @"未选择";
        return cell;
    }
    NSArray *changes = self.preview[@"changes"];
    if (!changes.count) return CSSettingsRow(tableView, self.busy ? @"正在检查变更" : (self.message ? @"暂时无法生成预览" : @"所选范围没有差异"), self.message ? @"请查看顶部提示后重试" : nil, self.busy ? @"ellipsis.circle" : (self.message ? @"exclamationmark.circle" : @"checkmark.circle"), UIColor.secondaryLabelColor, NO);
    NSDictionary *change = changes[path.row];
    NSString *key = change[@"key"], *module = change[@"module"];
    NSDictionary *labels = @{@"com.wechat.enhance.redenvelop.autoReceive":@"自动领取红包", @"com.wechat.enhance.redenvelop.autoReplyEnable":@"红包自动回复", @"kReceiveTransferAutoEnableKey":@"自动收款", @"kReceiveTransferAutoReplyEnableKey":@"收款自动回复", @"com.wechat.enhance.chat_group.account_profiles":@"账号分组和成员"};
    NSString *title = labels[key] ?: [CSBackupRegistry moduleTitles][module];
    id before = change[@"before"][@"value"], after = change[@"after"][@"value"];
    NSString *detail = nil;
    BOOL reset = [change[@"reset"] boolValue];
    if (reset) detail = @"恢复为未设置状态";
    else if ([after isKindOfClass:NSNumber.class]) {
        NSDictionary *entry = [CSBackupRegistry entryForDomain:change[@"after"][@"domain"] key:key];
        if ([entry[@"type"] isEqual:@"bool"]) detail = [NSString stringWithFormat:@"%@ → %@", before ? ([before boolValue] ? @"开启" : @"关闭") : @"未设置", [after boolValue] ? @"开启" : @"关闭"];
        else detail = [NSString stringWithFormat:@"%@ → %@", before ?: @"未设置", after];
    } else if ([key isEqual:@"com.wechat.enhance.chat_group.account_profiles"]) {
        NSMutableArray *removed = [NSMutableArray array];
        for (NSString *account in before) {
            NSMutableSet *ids = [NSMutableSet set];
            for (NSDictionary *tab in after[account][@"customTabs"]) [ids addObject:tab[@"id"]];
            for (NSDictionary *tab in before[account][@"customTabs"]) if (![ids containsObject:tab[@"id"]]) [removed addObject:tab[@"name"]];
        }
        detail = removed.count ? [NSString stringWithFormat:@"更新分组；移除：%@", [removed componentsJoinedByString:@"、"]] : @"更新所选账号的分组、成员和排序";
    } else if ([after isKindOfClass:NSString.class] && ![after hasPrefix:@"csbackup:"]) detail = [after length] > 80 ? [[after substringToIndex:80] stringByAppendingString:@"…"] : after;
    else detail = @"替换为备份中的值";
    return CSSettingsRow(tableView, title, detail, reset ? @"minus.circle" : @"arrow.triangle.2.circlepath", reset ? UIColor.systemOrangeColor : UIColor.secondaryLabelColor, NO);
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];if(path.section!=1&&path.section!=2)return;if(path.section==2&&!self.accounts.count)return;NSMutableSet *selected=path.section==1?self.selectedModules:self.selectedAccounts;NSString *value=(path.section==1?self.modules:self.accounts)[path.row];if([selected containsObject:value])[selected removeObject:value];else [selected addObject:value];[tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationNone];[self refreshPreview];
}
- (void)confirm {
    if(self.busy||!self.preview)return;
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"准备恢复所选配置" message:@"先保存恢复前保护备份，再生成待执行计划。请随后手动退出并重新打开微信；现在不会修改当前设置。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"准备恢复" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action){self.busy=YES;self.tableView.userInteractionEnabled=NO;self.navigationItem.rightBarButtonItem.enabled=NO;[CSBackupManager.sharedManager prepare:self.preview completion:^(__unused id result,NSError *error){self.busy=NO;self.tableView.userInteractionEnabled=YES;UIAlertController *resultAlert=[UIAlertController alertControllerWithTitle:error?@"未能准备恢复":@"恢复已准备" message:error.localizedDescription?:@"请手动退出并重新打开微信后应用。可在备份页取消待恢复计划。" preferredStyle:UIAlertControllerStyleAlert];[resultAlert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){if(!error)[self.navigationController popViewControllerAnimated:YES];else [self refreshPreview];}]];[self presentViewController:resultAlert animated:YES completion:nil];}];}]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
