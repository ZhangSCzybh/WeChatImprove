#import "CSBackupSettingsViewController.h"
#import "CSBackupManager.h"
#import "CSSettingsAppearance.h"
#import "CSBackupBootstrap.h"
#import "CSBackupPreviewViewController.h"
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "CSNavigationTitleSettingsViewController.h"
#import "CSTabBarStyleSettingsViewController.h"
#import "CSTouchTrailViewController.h"
#import "CSContactSeparatorSettingsViewController.h"
#import "CSNativeSettingsHost.h"
@interface CSBackupRepairViewController : UITableViewController
@property(nonatomic) NSArray<NSString *> *contacts;
@end
@implementation CSBackupRepairViewController
- (void)viewDidLoad {[super viewDidLoad];self.title=@"修复当前配置";CSSettingsPrepareTable(self.tableView);id contacts=[NSUserDefaults.standardUserDefaults objectForKey:@"com.wechat.tweak.navigation.contact.overrides"];self.contacts=[contacts isKindOfClass:NSDictionary.class]?[[contacts allKeys] sortedArrayUsingSelector:@selector(compare:)]:@[];}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {(void)tableView;(void)section;return 4+self.contacts.count;}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {(void)tableView;(void)section;return @"升级保护未能完成时，可在原有设置页面重新选择缺失图片或修正无效配置，然后返回备份页重试。插件功能在校验完成前保持等待；本页不会自动清除配置。其他设置仍使用原有授权检查。";}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {(void)tableView;UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];cell.textLabel.text=path.row<4?@[@"导航栏分隔图片",@"底栏普通及选中图标",@"触摸轨迹图片",@"其他插件设置"][path.row]:[@"联系人分隔图片 · " stringByAppendingString:self.contacts[path.row-4]];cell.textLabel.numberOfLines=0;cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;return cell;}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {[tableView deselectRowAtIndexPath:path animated:YES];UIViewController *controller=nil;switch(path.row){case 0:controller=[CSNavigationTitleSettingsViewController new];break;case 1:controller=[CSTabBarStyleSettingsViewController new];break;case 2:controller=[CSTouchTrailViewController new];break;case 3:controller=[[CSNativeSettingsControllerClass() alloc]init];break;default:controller=[[CSContactSeparatorSettingsViewController alloc]initWithContactId:self.contacts[path.row-4] contactName:nil contactAvatar:nil];break;}[self.navigationController pushViewController:controller animated:YES];}
@end

@interface CSBackupSettingsViewController () <UIDocumentPickerDelegate>
@property(nonatomic) NSArray *records;
@property(nonatomic) BOOL busy;
@property(nonatomic) BOOL maintenanceExpanded;
@property(nonatomic) NSString *loadError;
@end
@implementation CSBackupSettingsViewController
- (instancetype)init { return [super initWithStyle:UITableViewStyleInsetGrouped]; }
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"备份与恢复";
    self.records = @[];
    CSSettingsPrepareTable(self.tableView);
}
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self reload]; }
- (void)setWorking:(BOOL)working {
    self.busy = working;
    self.tableView.userInteractionEnabled = !working;
    self.navigationItem.prompt = working ? @"正在处理，请稍候…" : nil;
}
- (void)reload {
    [self setWorking:YES];
    [CSBackupManager.sharedManager list:^(NSArray *records, NSError *error) {
        self.records = records ?: @[];
        self.loadError = error.localizedDescription;
        if (error || !CSBackupIsReady()) self.maintenanceExpanded = YES;
        [self setWorking:NO];
        [self.tableView reloadData];
    }];
}
- (void)message:(NSString *)title detail:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 4; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0: return 1;
        case 1: return 3;
        case 2: return MAX(1, self.records.count);
        default: return self.maintenanceExpanded ? 4 : 1;
    }
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 1) return @"保存当前配置";
    if (section == 2) return self.records.count ? [NSString stringWithFormat:@"本机备份 · %lu 份", (unsigned long)self.records.count] : @"本机备份";
    if (section == 3) return @"恢复与维护";
    return nil;
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 1) return @"自动备份在配置停止变化约 30 秒后尝试保存，相同内容不重复保存。";
    if (section == 2) return self.records.count ? @"点开备份可预览恢复、分享或管理。手动和收藏的备份会持续保留。" : nil;
    if (section == 3) return @"备份包含插件设置、图片和账号分组，不含聊天记录、登录凭据或支付账本。导出文件未加密，请妥善保存。";
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    if (path.section == 0) {
        BOOL held = !CSBackupIsReady();
        NSString *title = self.loadError ? @"备份需要检查" : (held ? @"恢复等待处理" : @"本机配置备份");
        NSString *detail = self.loadError ?: CSBackupManager.sharedManager.status;
        return CSSettingsSummary(tableView, title, detail, self.loadError || held ? @"exclamationmark.shield" : @"externaldrive.badge.checkmark", self.loadError || held ? UIColor.systemOrangeColor : UIColor.systemGreenColor);
    }
    if (path.section == 1) {
        NSArray *titles = @[@"创建完整备份", @"从文件导入", @"自动备份"];
        NSArray *details = @[@"保存当前设置、图片和账号分组", @"加入本机备份列表，稍后选择恢复", @"配置变化后自动保存，保留最近 20 份"];
        NSArray *symbols = @[@"plus.circle.fill", @"square.and.arrow.down", @"clock.arrow.circlepath"];
        UITableViewCell *cell = CSSettingsRow(tableView, titles[path.row], details[path.row], symbols[path.row], path.row == 0 ? UIColor.systemGreenColor : UIColor.secondaryLabelColor, path.row != 2);
        if (path.row == 2) {
            UISwitch *toggle = [UISwitch new];
            toggle.on = CSBackupManager.sharedManager.isAutoBackupEnabled;
            toggle.onTintColor = UIColor.systemGreenColor;
            toggle.accessibilityLabel = @"自动备份";
            [toggle addTarget:self action:@selector(autoChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = toggle;
        }
        return cell;
    }
    if (path.section == 2) {
        if (!self.records.count) return CSSettingsSummary(tableView, @"还没有备份", @"创建第一份备份，或导入以前保存的文件。", @"tray", UIColor.tertiaryLabelColor);
        NSDictionary *record = self.records[path.row], *metadata = record[@"metadata"];
        BOOL legacy = [record[@"legacy"] boolValue], favorite = [metadata[@"favorite"] boolValue];
        NSString *kind = @{@"manual":@"手动", @"automatic":@"自动", @"protection":@"恢复前保护", @"upgrade":@"升级保护", @"imported":@"导入", @"legacy":@"旧版"}[record[@"kind"]] ?: @"备份";
        NSString *detail = legacy ? @"旧版原件保留 · 打开后校验" : [NSString stringWithFormat:@"%@ · %@%@\n%@ 项配置 · %@ 张图片 · %@", kind, CSSettingsBackupDate(record[@"createdAt"]), favorite ? @" · 已收藏" : @"", record[@"fieldCount"] ?: @0, record[@"assetCount"] ?: @0, [NSByteCountFormatter stringFromByteCount:[record[@"size"] longLongValue] countStyle:NSByteCountFormatterCountStyleFile]];
        return CSSettingsRow(tableView, metadata[@"name"] ?: record[@"name"], detail, favorite ? @"star.fill" : @"archivebox", favorite ? UIColor.systemOrangeColor : UIColor.secondaryLabelColor, YES);
    }
    if (path.row == 0) {
        UITableViewCell *cell = CSSettingsRow(tableView, @"恢复辅助操作", self.maintenanceExpanded ? @"取消计划、重试恢复或修复配置" : @"需要处理恢复问题时展开", @"wrench.and.screwdriver", UIColor.secondaryLabelColor, YES);
        cell.accessoryType = UITableViewCellAccessoryNone;
        UIImageView *chevron = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:self.maintenanceExpanded ? @"chevron.up" : @"chevron.down"]];
        chevron.tintColor = UIColor.tertiaryLabelColor;
        cell.accessoryView = chevron;
        cell.accessibilityValue = self.maintenanceExpanded ? @"已展开" : @"已折叠";
        return cell;
    }
    NSArray *titles = @[@"取消待恢复计划", @"重试未完成的恢复", @"修复当前配置"];
    NSArray *details = @[@"尚未应用的计划可取消；未完成的提交会先回滚", @"重新校验并继续处理启动时的恢复", @"重新选择缺失图片或修正无效配置"];
    NSArray *symbols = @[@"xmark.circle", @"arrow.clockwise", @"slider.horizontal.3"];
    return CSSettingsRow(tableView, titles[path.row - 1], details[path.row - 1], symbols[path.row - 1], path.row == 1 ? UIColor.systemRedColor : UIColor.secondaryLabelColor, YES);
}
- (void)autoChanged:(UISwitch *)sender { [CSBackupManager.sharedManager enableAutoBackup:sender.on]; }
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];
    if (self.busy) return;
    if (path.section == 2 && self.records.count) {
        [self setWorking:YES];
        NSDictionary *record = self.records[path.row];
        [CSBackupManager.sharedManager load:record completion:^(NSDictionary *snapshot, NSError *error) {
            [self setWorking:NO];
            if (error) [self message:@"无法读取备份" detail:error.localizedDescription];
            else [self showRecord:record snapshot:snapshot anchor:[tableView cellForRowAtIndexPath:path]];
        }];
    } else if (path.section == 1 && path.row == 0) [self create];
    else if (path.section == 1 && path.row == 1) {
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeData] asCopy:YES];
        picker.delegate = self;
        picker.allowsMultipleSelection = NO;
        [self presentViewController:picker animated:YES completion:nil];
    } else if (path.section == 3) {
        if (path.row == 0) {
            self.maintenanceExpanded = !self.maintenanceExpanded;
            [tableView reloadSections:[NSIndexSet indexSetWithIndex:3] withRowAnimation:UITableViewRowAnimationAutomatic];
        } else if (path.row == 1) [self confirmCancel];
        else if (path.row == 2) {
            [self setWorking:YES];
            CSBackupRetryStartup(^(NSError *error) {
                [self setWorking:NO];
                [self message:error ? @"恢复仍待处理" : @"校验已完成" detail:error.localizedDescription ?: @"请重新打开微信，以完整初始化所有插件功能。"];
                [self reload];
            });
        } else {
            [self setWorking:YES];
            [CSBackupManager.sharedManager checkRepairAccess:^(__unused id value, NSError *error) {
                [self setWorking:NO];
                if (error) [self message:@"暂时不能修复" detail:error.localizedDescription];
                else [self.navigationController pushViewController:[[CSBackupRepairViewController alloc] initWithStyle:UITableViewStyleInsetGrouped] animated:YES];
            }];
        }
    }
}
- (void)create {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"创建完整备份" message:@"保存当前插件配置、图片和账号分组。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field){field.placeholder=@"名称（可留空）";}];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action){NSString *name=[alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];if(!name.length){NSDateFormatter *date=[NSDateFormatter new];date.dateFormat=@"yyyy-MM-dd HH:mm";name=[@"手动备份 " stringByAppendingString:[date stringFromDate:NSDate.date]];}[self setWorking:YES];[CSBackupManager.sharedManager create:name completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"保存失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmCancel {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"取消待恢复计划" message:@"保留当前配置、原备份和保护备份。已开始但未完成的事务必须先回滚。" preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"返回" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"取消计划" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager cancelPending:^(__unused id result,NSError *error){[self setWorking:NO];if(error)[self message:@"无法取消" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)showRecord:(NSDictionary *)record snapshot:(NSDictionary *)snapshot anchor:(UIView *)anchor {
    NSString *message=[NSString stringWithFormat:@"来源版本 %@ · %lu 项配置 · %lu 张图片%@",snapshot[@"source"][@"pluginVersion"],(unsigned long)[snapshot[@"fields"] count],(unsigned long)[snapshot[@"assets"] count],[snapshot[@"warnings"] count]?[@"\n" stringByAppendingString:[snapshot[@"warnings"] componentsJoinedByString:@"\n"]]:@""];
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:record[@"metadata"][@"name"]?:snapshot[@"name"] message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:@"预览恢复" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self.navigationController pushViewController:[[CSBackupPreviewViewController alloc]initWithSnapshot:snapshot] animated:YES];}]];
    [alert addAction:[UIAlertAction actionWithTitle:@"导出到文件 / 分享" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager exportSnapshot:snapshot completion:^(NSURL *url,NSError *error){[self setWorking:NO];if(error){[self message:@"导出失败" detail:error.localizedDescription];return;}UIActivityViewController *share=[[UIActivityViewController alloc]initWithActivityItems:@[url] applicationActivities:nil];share.popoverPresentationController.sourceView=anchor?:self.view;share.popoverPresentationController.sourceRect=(anchor?:self.view).bounds;share.completionWithItemsHandler=^(__unused UIActivityType type,__unused BOOL complete,__unused NSArray *items,__unused NSError *shareError){[NSFileManager.defaultManager removeItemAtURL:url error:NULL];};[self presentViewController:share animated:YES completion:nil];}];}]];
    if(![record[@"legacy"] boolValue]){
        [alert addAction:[UIAlertAction actionWithTitle:@"重命名" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){[self renameRecord:record];}]];
        BOOL favorite=[record[@"metadata"][@"favorite"] boolValue];[alert addAction:[UIAlertAction actionWithTitle:favorite?@"取消收藏":@"收藏（保留不自动清理）" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){NSMutableDictionary *metadata=[record[@"metadata"] mutableCopy];metadata[@"favorite"]=favorite?@NO:@YES;[self setWorking:YES];[CSBackupManager.sharedManager updateMetadata:metadata record:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"修改失败" detail:error.localizedDescription];else [self reload];}];}]];
        [alert addAction:[UIAlertAction actionWithTitle:@"删除备份" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self deleteRecord:record];}]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];alert.popoverPresentationController.sourceView=anchor?:self.view;alert.popoverPresentationController.sourceRect=(anchor?:self.view).bounds;[self presentViewController:alert animated:YES completion:nil];
}
- (void)renameRecord:(NSDictionary *)record {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"重命名本机备份" message:@"仅修改本机显示名称，原始快照信息保留。" preferredStyle:UIAlertControllerStyleAlert];[alert addTextFieldWithConfigurationHandler:^(UITextField *field){field.text=record[@"metadata"][@"name"]?:record[@"name"];}];[alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){NSString *name=[alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];if(!name.length||name.length>128){[self message:@"名称无效" detail:@"请输入 1–128 个字符。"] ;return;}NSMutableDictionary *metadata=[record[@"metadata"] mutableCopy];metadata[@"name"]=name;[self setWorking:YES];[CSBackupManager.sharedManager updateMetadata:metadata record:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"修改失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)deleteRecord:(NSDictionary *)record {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"删除这份备份？" message:@"只删除所选备份，不改变当前配置。" preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[alert addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){[self setWorking:YES];[CSBackupManager.sharedManager remove:record completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"删除失败" detail:error.localizedDescription];else [self reload];}];}]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {(void)controller;if(!urls.count)return;[self setWorking:YES];[CSBackupManager.sharedManager importURL:urls.firstObject completion:^(__unused id value,NSError *error){[self setWorking:NO];if(error)[self message:@"导入失败" detail:error.localizedDescription];else [self reload];}];}
@end
