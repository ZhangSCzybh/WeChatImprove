#import "CSSettingsAppearance.h"

void CSSettingsPrepareTable(UITableView *tableView) {
    tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    tableView.tintColor = UIColor.systemGreenColor;
    tableView.rowHeight = UITableViewAutomaticDimension;
    tableView.estimatedRowHeight = 72;
    tableView.sectionHeaderTopPadding = 8;
    tableView.separatorInset = UIEdgeInsetsMake(0, 56, 0, 16);
    tableView.cellLayoutMarginsFollowReadableWidth = YES;
}

UITableViewCell *CSSettingsRow(UITableView *tableView, NSString *title, NSString *detail,
                              NSString *symbol, UIColor *tint, BOOL disclosure) {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CSSettingsPresentation"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CSSettingsPresentation"];
    cell.accessoryView = nil;
    cell.accessoryType = disclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    cell.selectionStyle = disclosure ? UITableViewCellSelectionStyleDefault : UITableViewCellSelectionStyleNone;
    cell.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    cell.tintColor = tint ?: UIColor.systemGreenColor;
    cell.accessibilityTraits = disclosure ? UIAccessibilityTraitButton : UIAccessibilityTraitNone;
    UIListContentConfiguration *content = [UIListContentConfiguration subtitleCellConfiguration];
    content.text = title;
    content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    content.textProperties.color = UIColor.labelColor;
    content.textProperties.numberOfLines = 0;
    content.secondaryText = detail;
    content.secondaryTextProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    content.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    content.secondaryTextProperties.numberOfLines = 0;
    content.textToSecondaryTextVerticalPadding = 5;
    content.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(14, 16, 14, 16);
    if (symbol.length) {
        content.image = [UIImage systemImageNamed:symbol];
        content.imageProperties.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:21 weight:UIImageSymbolWeightMedium];
        content.imageProperties.tintColor = tint ?: UIColor.secondaryLabelColor;
        content.imageProperties.reservedLayoutSize = CGSizeMake(28, 28);
        content.imageToTextPadding = 12;
    }
    cell.contentConfiguration = content;
    cell.accessibilityLabel = nil;
    cell.accessibilityValue = nil;
    return cell;
}

UITableViewCell *CSSettingsSummary(UITableView *tableView, NSString *title, NSString *detail,
                                  NSString *symbol, UIColor *tint) {
    UITableViewCell *cell = CSSettingsRow(tableView, title, detail, symbol, tint, NO);
    UIListContentConfiguration *content = [(UIListContentConfiguration *)cell.contentConfiguration copy];
    content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle2];
    content.secondaryTextProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    content.textToSecondaryTextVerticalPadding = 9;
    content.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(22, 18, 22, 18);
    content.imageProperties.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:30 weight:UIImageSymbolWeightMedium];
    content.imageProperties.reservedLayoutSize = CGSizeMake(38, 38);
    cell.contentConfiguration = content;
    return cell;
}

NSString *CSSettingsBackupDate(NSDate *date) {
    if (![date isKindOfClass:NSDate.class]) return @"旧版备份";
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateStyle = NSDateFormatterMediumStyle;
    formatter.timeStyle = NSDateFormatterShortStyle;
    formatter.doesRelativeDateFormatting = YES;
    return [formatter stringFromDate:date];
}
